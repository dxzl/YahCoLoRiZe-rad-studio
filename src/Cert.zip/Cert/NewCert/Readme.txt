---------------------------------------------------------------------------------------------
!!!!!!!!!!!!!!!!!!!!!!THIS WORKS!!!!!!!!!!!!!!!!!!!!!!
---------------------------------------------------------------------------------------------

https://gallery.technet.microsoft.com/scriptcenter/Self-signed-certificate-5920a7c6/view/Discussions

// Windows signing certificate

// here's what I used (but change password):
// put New-SelfSignedCertificateEx.ps1 in PsScripts folder
cd \
cd PsScripts
type Readme.txt

// !!!! MUST import script as a MODULE if you haven't !!!!
Import-Module .\New-SelfSignedCertificateEx.ps1

// WORKED!
New-SelfSignedCertificateEx -Subject "CN=DTS, OU=Development" -EKU "Code Signing" -IsCA $false -KeySpec "Signature" -KeyUsage "DigitalSignature" -FriendlyName "Discrete-Time Systems" -NotAfter $([datetime]::now.AddYears(100)) -Path "C:\PsScripts\DtsUWP.pfx" -Password (ConvertTo-SecureString "MyPassword" -AsPlainText -Force) -Exportable

get:

Thumbprint                                Subject
----------                                -------
67E2B13C181ECA84342030DA517949FFCB333DCC  CN=DTS, OU=Development
---------------------------------------------------------------------------------------------
To get the .cer certificate to ship with software:

1. double-click to import, enter the password and check the "exportable" box
2. Run certmgr.msc and go to Personal->Certificates Right-click "DTS" and click
   "all-tasks" Export. check NO don't export private key, follow on
   and export dts.cer... then right-click delete the DTS key from the windows store.
3. double-click to install dts.cer or ship with software signed with the corresponding pfx
