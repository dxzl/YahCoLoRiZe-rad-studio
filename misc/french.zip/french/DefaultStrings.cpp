#include <vcl.h>
#include <Controls.hpp>
#include "Main.h"
// Include header files common to all files before this directive!
#pragma hdrstop

//************************************************************************
// This table allows us to maintain a constant index across various
// platforms over the IRC network, independant of the fonts on a given machine.
const char* FONTS[] =
{
// Internal fonts for which we embed a code-index to represent it in
// the IRC text... 1-99 (0 is reserved to indicate the default font)
// ok to add as many as you want... but change FONTITEMS in the header file!
//
// Completely case independant...
"Courier New", // 1 (do not change) USER_DEF_TYPE
"Tahoma", // 2 (do not change) PALTALK_DEF_TYPE
"Arial",
"Arial Black",
"Arial Narrow",
"Arial Unicode MS",
"Batang",
"Batangche",
"Book Antiqua",
"Bookman Old Style", // 10
"Bookshelf Symbol 7",
"Browallia New",
"Browalliaupc",
"Buxton Sketch",
"Calibri",
"Calibri Light",
"Cambria",
"Cambria Math",
"Candara",
"Century", // 20
"Century Gothic",
"Comic Sans MS",
"Consolas",
"Constantia",
"Corbel",
"Cordia New",
"Cordiaupc",
"Courier",
"Daunpenh",
"David", // 30
"Default",
"Dilleniaupc",
"Dokchampa",
"Euphemia",
"Fangsong",
"Fixedsys",
"Franklin Gothic Medium",
"Freesiaupc",
"Gabriola",
"Garamond", // 40
"Gautami",
"Georgia",
"Gelvetica",
"Impact",
"Irisupc",
"Iskoola Pota",
"Jasmineupc",
"Javanese Text",
"Kaiti",
"Kalinga", // 50
"Kartika",
"Khmer UI",
"Kodchiangupc",
"Kokila",
"Lao UI",
"Latha",
"Leelawadee",
"Lucida Console",
"Lucida Sans Unicode",
"Malgun Gothic", // 60
"Mangal",
"Marlett",
"Meiryo",
"Meiryo UI",
"Miriam",
"Miriam Fixed",
"Modern",
"Mongolian Baiti",
"Moolboran",
"Mt Extra", // 70
"Mv Boli",
"Myanmar Text",
"Nyala",
"Palatino Linotype",
"Plantagenet Cherokee",
"Raavi",
"Roman",
"Script",
"Sketchflow Print",
"Small Fonts", // 80
"Symbol",
"System",
"Terminal",
"Times New Roman",
"Traditional Arabic",
"Trebuchet MS",
"Verdana",
"Webdings",
"Wingdings",
"Wingdings 2", // 90
"Wingdings 3",
"@Arial Unicode MS",
"@Batang",
"@Dotum",
"@Kaiti",
"@Malgun Gothic",
"@Meiryo UI",
"@Mingliu",
"@Mingliu_hkscs", // 99
};
//************************************************************************
const char * VIEWS[] =
{
// ViewStatus Text Display
"Vue: originale",
"Vue: trait�e",
"Vue: IRC",
"Vue: HTML",
"Vue: RTF",
"Vue: Off",
"Vue: ?",
};
//************************************************************************
const char * CLIENTS[] =
{
// ClientStatus Text Display
"YahELite",
"mIRC",
"IceChat",
"Hydra",
"LeafChat",
"Vortec",
"XiRCON",
"Paltalk",
"Trinity",
};
//************************************************************************
const char * WINGEDITMAINMENU[] =
{
  "Options",

  // These Wings are in "ANSI UTF-8" a backslash
  // escape is in front of the " or \ char.
  "Insérez Wingding",
  "<~*-,._.,-*~'^'~*-,",
  ",-*~'^'~*-,._.,-*~>",
  "´¯`~°³²¹ºª¤", // "��`~�������"
  "¤ªº¹²³°~´¯`", // "�������~��`"
  "\"°º©o., ", // "\"���o., "
  " ,.o©º°\"", // " ,.o���\""
  "««", // "��"
  "»»", // "��"
  "<-.¸¸.·´¯", // "<-.��.���"
  "¯`·.¸¸.->", // "�`�.��.->"
  "03.;'``~<04@",
  "04@03>~``';.",
  "04¶09¦10+11) ", // "04�09�10+11) "
  " 11§10:09¬04>", // " 11�10:09�04>"
  "`·.<º)))><.·´", // "`�.<�)))><.��"
  "`·.><(((º>.·´", // "`�.><(((�>.��"
  "3¤~»}4@3{«~¤", // "3�~�}4@3{�~�"
  "«¤´¤»¥«¤´¤»¥«¤´¤»", // "�����������������"
  " Këw£ ", // " K�w� "
  "»4¡«»10¡«»12¡«", // "�4���10���12��"
  "02,01 04\\01,04\\08\\04,08\\/08,04/01/04,01/01 ",

  "-",
  "Insertion De Concevoir-Fenêtre Principale",
  "-",
  "(C) Couleur",
  "(F) Type police",
  "(S) Taille police",
  "(B) Gras",
  "(I) Italique",
  "(U) Souligné",
  "(O) Plain Text",
  "(P) Protégé",
  "(p) Fin protégé",

  "-",
  "Optimize",

  "-",
  "Exportation Vers Le Texte-Dossier",
  "Importation De Texte-Dossier",
  "-",
  "économisez et sortez",
  "stoppé",

  "vue",

  "RTF (Color Text Edit)",
  "IRC (Plain Text Edit)",

  // Help
  "aider",
};
//************************************************************************
const char * EDITPOPUPMENU1[TOTALEDITPOPUPMENU1] =
{
  "Annuler tout Wing-Edits",
  "-",
  "Ajouter New Wing-Pair",
  "De importer fen�tre de conception principal",
  "-",
  "Cut",
  "Modifier Wing s�lectionn�s",
  "-",
  "Copy",
  "Paste",
  "-",
  "Effacer toute la liste",
};
//************************************************************************
const char * EDITPOPUPMENU2[] =
{
  "Espace libre", // Clear
  "Annuler", // Undo
  "-",
  "Cut",
  "Copy",
  "Paste",
  "Effacer", // Delete
  "-",
  "S�lectionner tout", // Select All
  "-",
  "Basculer Vue", // Toggle View Mode
  "-",

  "Ajouter un effet texte", // Add Text Effects

  "Code De Couleur (Crtl-K)",
  "Type police",
  "Taille police",
  "Bold (Ctrl-B)",
  "Italics (Ctrl-R)",
  "Soulignez (Ctrl-U)",

  "-",
  "Enregistrer et Quitter", // Save and Exit
  "Quitter sans enregistrer",
};
//************************************************************************
const char* COLORDIALOGMSG[] =
{
  "Vert Blend", //0
  "RGB Color", //1
  "Horiz Blend", //2
  "Random", //3
  "Transparent", //4
  "Cancel", //5
  "Morph Couleurs", //6
  "Remplacer Couleurs", //7
  "", //8
  "", //9
  "Couleur de premier plan", // 10
  "Fond Couleur", // 11
  "Effet: Premier plan Alternatif", // 12
  "Couleurs de morphing", // 13
  "Remplacer les couleurs", // 14
  "", // 15
  "", // 16
  "Effect: Underline Color A", // 17
  "Effect: Underline Color B", // 18
};
//************************************************************************
const char* WEBEXPORTMSG[] =
{
  "", // 0
  
  "Top Web Page marge (pixels)", // 1
  "Web-marge de gauche (pixels)", // 2
  "Web page BG Color", // 3

  "Cliquez pour s�lectionner la couleur de fond\n"
  "pour votre nouvelle page Web...", // 4

  "D�cochez cette option si votre g�n�rez un page web compl�te.\n"
  "Cochez cette case pour copier HTML dans le Presse-papiers de Windows.\n"
  "Vous pouvez ensuite coller HTML dans d'autres programmes tels que E -Mail.", // 5

  "Cochez cette case pour utiliser un web-lien vers une image\n"
  "pour la page web que nous produisons.", // 6

  "Cochez cette case pour �viter que l'image de fond\n"
  "� partir de d�filement en m�me temps que le texte.", // 7

  "Cochez cette case pour inclure la balise META auteur!", // 8

  "Cochez cette case pour inclure la balise META title!", // 9

  "Cochez cette case pour g�n�rer un bouton HOME de la page!", // 10

  "R�p�ter: r�p�te l'image horizontalement et verticalement.\n"
  "R�p�tez-X: r�p�te image horizontalement seulement.\n"
  "R�p�tez-Y: r�p�te l'image veritcally seulement.\n"
  "No-repeat: affiche l'image en l'�tat.\n\n"
  "(Remarque: Si non - r�p�tition est activ�e, l'image pisition\n"
  "fix� par les curseurs en haut de cette bo�te de dialogue 0%-100%)", // 11

  "Cochez cette case pour forcer l'insertion des espaces ins�cables\n"
  "� la fin de lignes. Cela ne devrait �tre n�cessaire pour la compatibilit�\n"
  "avec les anciens navigateurs qui ignorent le style white-space.", // 12

  "", // 13
  "", // 14
  "", // 15
  "", // 16

  "Utilisez le titre", // 17
  "Nom de Use Auteur", // 18
  "Assurez Accueil Bouton", // 19
  "Ins�rer des espaces ins�cables", // 20
  "Blanc-Space style", // 21

  "", // 22
  "", // 23
  "", // 24
  "", // 25

  "Hauteur Ligne: ", // 26
};
//************************************************************************
const char * EDITMSG[] =
{
  // Sous-titre
  "R�visez Filoche", // 0

  // Label5
  "Quitt�", // 1

  // Label6
  "Le droit", // 2

  // Label7
  "Lehaut Fronti�res (pattern auto-repeats)", // 3

  // Label8
  "LeC�t�Gauche", // 4

  // Label9
  "LeC�t�Juste", // 5

  // Label10
  "FondFronti�reCouleur:", // 6

  // TopBottomBorders
  "Permis", // 7

  // SideBorders
  "LesC�t�sOntpermis", // 8

  // Button1
  "Sortie", // 9

  // Button2
  "CarteCaract�re", // 10

  // Button3
  "R�dacteurFonte", // 11

  // Edit1->Hint
  "Appuyez sur ENTRER pour enregistrer et quitter.\n"
  "Appuyez sur Echap pour quitter sans enregistrer.\n"
  "CTRL + T Active ou d�sactive l'affichage.\n"
  "Faites un clic droit pour afficher le menu pop-up.", // 12

  // LeftWingsListBox->Hint, RightWingsListBox->Hint (not in edit-mode)
  "Double-cliquez sur un �l�ment pour le modifier.\n"
  "Faites un clic droit pour afficher le menu contextuel.\n"
  "Cochez la case pour activer l'aile paire.\n"
  "Appuyez sur la touche ESC pour abandonner.", // 13

  // TopBottomEdit->Hint, LeftSideEdit->Hint, RightSideEdit->Hint
  "Gauche-cliquez sur Editer.", // 14

  // LeftWingsListBox->Hint, RightWingsListBox->Hint (in Edit-mode only)
  "Gauche-cliquez sur Editer.\n"
  "Faites un clic droit pour afficher le menu pop-up.", // 15

  // Spares
  "", //16
  "", //17
  "", //18
  "", //19

  // Messages généraux...

  // Instructions d'importation
  "Pour importer, pour concevoir une aile D'UN LIGNE dans la FENÊTRE PRINCIPALE. Press\n"
  "Le PROCESSUS et ajoute n'importe quels effets que vous pouvez vouloir. Dans le rédacteur en chef d'aile, \n"
  "claquez la boîte que vous voulez importer dans (les Gauches ailes ou les Droites), \n"
  "Le droit de claquement de surgir ce menu et claquer cette sélection de menu de nouveau.", // 20

  "L'Erreur Important des Ailes ...", // 21

  "Les Ailes D'exportation Comme le Texte", // 22

  "L'Erreur Exportant des Ailes ...", // 23


  "Opération non autorisée dans cette vue!", // 24
  "Vous devez sélectionner le texte pour effectuer cette opération!", // 25

  "Cliquez sur une bordure pour le modifier.\n\n"
  "Double-cliquez sur une aile pour le modifier.\n\n"
  "Faites un clic droit dans la fenêtre d'édition pour\n"
  "voir le menu pop-up.\n\n"
  "Cliquez sur \"Afficher\" pour modifier les codes IRC brutes.\n\n"
  "Cliquez sur \"Options\" pour exporter / ailes d'importation,\n"
  "ou pour modifier la partie sélectionnée de la\n"
  "la couleur des ailes, etc\n\n"
  "Vous pouvez également concevoir une aile dans la main\n"
  "YahCoLoRiZe fenêtre, puis l'importer via\n"
  "\"Options->Insérer partir de la fenêtre Main Design\".", //26

  "Wing-liste est corrompu ... réparé", //27
  "Cliquez ou double-cliquez sur un élément pour le modifier ...", //28

  // Spares
  "", //29

  // DO NOT TRANSLATE THE FOLLOWING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  "charmap.exe", //30
  "eudcedit.exe", //31

  // Spares
  "", //32
  "", //33
  "", //34
};
//************************************************************************
const char* REPLACEDLGMAINMENU[] =
{
  "Insérer",

  "(C) Couleur",
  "(F) Type police",
  "(S) Taille police",
  "(B) Gras",
  "(I) Italique",
  "(U) Souligné",
  "(O) Texte brut",
  "(P) Protégée",
  "(p) Fin Protégée",
  "(N) Saut de page",

  "Éditez", // (Edit) EditMenu

  "Dégagez", // (Clear)
  "Annuler",
  "-",
  "Couper",
  "Copier",
  "Coller (couleur)",
  "Coller (pas de couleur)",
  "-",
  "Sélectionner tout",
  "-",
  "Basculer Vue", // Toggle View
  "-",
  "Optimiser",

  "Aide", // Help
};
//************************************************************************
const char* REPLACEDLGPOPUPMENU[] =
{
  "Dégagez", // (Clear)
  "Annuler",
  "-",
  "Couper",
  "Copier",
  "Coller (couleur)",
  "Coller (pas de couleur)",
  "-",
  "Sélectionner tout",
  "-",
  "Basculer Vue", // Toggle View
  "-",
  "Optimiser",
};
//************************************************************************
const char* REPLACEMSG[] =
{
"Rechercher/Remplacer (texte seulement)", // Titres fen�tre 0
"Trouver (texte s�lectionn� uniquement)",
"Rechercher/Remplacer (document complet)",
"Trouver (document complet)",
"",
"Wrap Around", // Cases � cocher 5
"Sensible � la casse",
"Mot entier",
"",
"&Up", // Boutons 9
"&Down",
"&Remplacer",
"Remp Tous",
"&Annuler",
"",
"Rechercher", // Labels 15
"Remplacer",
"Touches F3/F4 le bas/vers le haut",
"",
"Texte non trouvé!", // Trouver le statut de retour 19
"Recherche terminée!",
"Erreur à la recherche!",
"",
"Remplacement de texte.", // Divers 23
"Fin recherche de texte.\n",
" Remplacements effectués.",
"Remplacer chaine n'a que des codes de format!", // 26
"", // 27
"Cliquez sur la découverte ou remplacer l'appareil\n"
"pour le modifier...", // 28
//------------------------
// Help text (29)
"Presse Trouver bas pour rechercher vers l'avant pour le texte dans la zone Rechercher.\n"
"Presse Trouver Jusqu'à recherche vers l'arrière pour le texte dans la zone Rechercher.\n"
"Appuyez sur Remplacer pour remplacer le texte qui a été trouvé avec le texte"
"dans le \"Remplacer\" boîte .\n"
"Appuyez sur \"Remplacer tout\" pour remplacer toutes les occurrences.\n\n"
"Pour trouver/remplacer sur une zone particulière d'un document, faites glisser le "
"souris dessus pour le sélectionner ( il doit y avoir un ou plus complète "
"lignes de texte !). La barre de titre va maintenant dire \"(texte sélectionné "
"seulement)\"\n\n"
"1 ) Utilisez le menu Insertion pour ajouter des couleurs et de formatage de texte. (Première "
"cliquez sur la case que vous voulez insérer dans le sélectionner!)\n"
"2 ) Faites un clic droit pour le menu contextuel pour copier/coller du texte, etc\n"
"3 ) Vous pouvez utiliser (Maj+Ins)/(Maj+Suppr) pour insérer/supprimer le texte.\n"
"4 ) Gauche - cliquez faites glisser la souris pour sélectionner des zones de texte (ou maintenez "
"la touche shift et appuyez sur les touches fléchées).\n\n"
"Exemple 1: Pour remplacer toutes les occurrences d'une couleur particulière:\n"
"a. Dans le programme principal, cliquez \"Afficher\" et sélectionnez \"codes de l'IRC\".\n"
"b. Dans le programme principal, faites glisser la souris sur la couleur que vous voulez "
"pour changer (\"C#FF00FF\" par exemple), faites un clic droit de copie, il, "
"puis faites un clic droit et \"Coller (couleur)\" dans la zone Rechercher.\n"
"c. Maintenant copier/coller une nouvelle couleur dans la \"Remplacer\" case ou "
"utiliser le menu Insertion pour ajouter un code couleur.\n"
"d. Modifier le remplacer un code couleur à votre goût, (Astuce: type a "
"caractère factice après le code de couleur et cliquez sur Affichage->Couleur "
"pour avoir un aperçu de son apparence, alors vous devez revenir à "
"View->codes à supprimer le caractère factice.)\n"
"e. Appuyez sur \"Remplacer tout\" et toutes les couleurs C#FF00FF RGB seront "
"remplacé par la nouvelle couleur.\n"
"f. Dans le programme principal, cliquez \"Afficher\" pour voir les nouvelles couleurs.\n\n"
"Exemple 2: Pour chercher/remplacer du texte multi-ligne:\n"
"a. Choisir, dit un paragraphe de texte dans le document principal et "
"droit - cliquez sur Copier dans le presse papier.\n"
"b. désélectionner le texte en cliquant n'importe où dans le document pour qu'il "
"ne sera pas confondu avec une recherche de zone.\n"
"c. Cliquez sur Modifier->Trouvez d'élever cette boîte de dialogue et cliquez-droit sur "
"\"Coller ordinaire\" pour ajouter le texte de ce paragraphe.\n"
"d. Maintenant, vous pouvez cliquer sur \"Trouver Up\" ou \"Trouver bas\" pour voir si la "
"paragraphe apparaît plus d'une fois.\n\n"
"NOTE: Lorsque le mode d'affichage principal est \"transformés\", le texte de Recherche est "
"toujours dépouillé de tout format-codes pour effectuer la recherche, mais "
"Remplacer le texte est autorisé à avoir format-codes. Lorsque le principal "
"mode d'affichage est \"codes de l'IRC\" ou \"origine\", à la fois la Recherche et "
"Remplacer les boîtes à textes peuvent avoir des codes premières au format texte.", // 29
//----------------------------
// Hints
"Vue", // 30
"Modifier l'affichage", // 31
};
//************************************************************************
const char* SPELLINGMSG[] =
{
"V�rificateur d'orthographe", // Titre de la fen�tre 0
"Mon Dictionnaire", // DlgShowDict.cpp
"Choisir dictionnaire", // DlgChooseDict.cpp
"",
"",
"",
"Langue", // Boutons 6
"Remplacer",
"Remplacer tout",
"Aide",
"Ignorer",
"Ignorer tout",
"Fermer",
"Ajouter un mot",
"Del Mot (s)",
"",
"Mon Dictionnaire", // (dictionnaire personnalis�) l�gende de bo�te de dialogue 16
"Langue", // (choisissez dictionnaire) Sous-dialogue l�gende 17
"Supprimer s�lectionn�s", // Sous-dialogue 18
"Aide",
"Fermer",
"D�ccord",
"",
"",
"",
"Entrées de dictionnaire personnalisé Max est:", // Cordes 25
"Aucune erreur trouvée, modifier le dictionnaire personnalisé?", // 26
"Impossible de vérifier l'orthographe sur ce système ...", // 27

"Impossible de trouver le dictionnaire. Faites une recherche sur le Web pour\n"
"\"OpenOffice Dictionnaires\" et décompressez le. aff et fichiers. dic pour le\n"
"dictionnaire de télécharger dans notre dossier de données d'application,\n"
"généralement \"C:\\Program Files (x86)\\\n"
"Discrete-Time Systems\\YahCoLoRiZe\\Dict\"", // 28

"", // 29

"Aucune vérification orthographique: Impossible de trouver hunspell.dll\n"
"Essayez de désinstaller puis de réinstaller YahCoLoRiZe ...", // 30

"Ajouter le mot courant de mon dictionnaire ...", // 31
"Effacer le mot � partir du dictionnaire ...", // 32
"Choisissez un hunspell (Open Office) dictionnaire ...", // 33
"",
"Hunspell.dll", // hunspell correcteur orthographique DLL 35
"",
"",
"",
"",
"Maintenez la touche Ctrl enfonc�e et cliquez sur les �l�ments que vous\n"
"souhaitez supprimer ...", // 40 astuces
"",
"",
"",
"",
"",
// --------- Texte d'aide pour DlgShowDict.cpp
"Sélectionnez le mot (s) que vous souhaitez supprimer en maintenant la touche Ctrl\n"
"et les (ou maintenez la touche Maj enfoncée et cliquez pour sélectionner une plage\n cliquant"
"de mots). Appuyez sur la touche Suppr ou cliquez sur \"Supprimer les éléments sélectionnés\"\n"
"pour supprimer les mots de la liste ... Cliquez \"Fermer\".", // 46

// --------- Texte d'aide
"Un mot mal orthographié apparaît dans l'édition-top box avec des suggestions\n"
"apparaissant dans la boîte de liste de gauche. Cliquez sur une des suggestions\n"
"ou saisir un nouveau mot.\n\n"
"Cliquez sur \"Remplacer\" pour remplacer un mot ou \"Remplacer tout\" pour remplacer tous les\n"
"les mêmes fautes d'orthographe de ce mot tout au long du\n"
"document. De même, vous pouvez cliquer sur \"Ignorer\" à continuer le sort\n"
"vérifier sans remplacer le mot ou \"Tout ignorer\" si le mot est\n"
"bien tel quel.\n\n"
"Cliquez sur \"Langue\" pour faire apparaître une liste des dictionnaires disponibles.\n"
"Dictionnaires sont constitués chacun de deux fichiers, fr_FR.aff et fr_FR.dic\n"
"pour le dictionnaire anglais, par exemple. Vous pouvez placer plusieurs\n"
"dictionnaires dans le répertoire suivant:\n\n"
"\\Program Files\\Discrete-Time Systems\\YahCoLoRiZe\\Dict\\\n\n"
"Assurez-vous de copier les deux fichiers (.aff/.dic). Fichiers zip de disponible\n"
"les dictionnaires: http://archive.services.openoffice.org/pub/\n"
"mirror/OpenOffice.org/contrib/dictionaries/\n\n"
"Cliquez sur \"Ajouter Word\" à ajouter un mot à votre propre coutume \"Mon Dictionnaire\".\n"
"En cliquant sur \"Del Word\" fera apparaître une boîte de liste qui vous permet de\n"
"sélectionner des mots à supprimer de \"Mon Dictionnaire\". Appuyez et maintenez le\n"
"Touche Ctrl et cliquez sur plusieurs mots, puis appuyez sur la touche Suppr pour supprimer\n"
"elles.\n\n"
"Crédits: Ce orthographe orthographique est rendu possible par les créateurs\n"
"de Hunspell ainsi que l'Open Office Dictionnaires. L'DLL compilés par\n"
"Chris de www.progui.co.uk. Les dictionnaires sont de openoffice.org. Hunspell\n"
"est avalible à: hunspell.sourceforge.net.", // 47
};
//************************************************************************
const char * PLAYMSG[] =
{
  // UseDLL->Hint
  "V�rifiez-le pour mIRC/Vortec pour permettre l'utilisation de burst-\n"
  "interval sans se d�shabiller des espaces suppl�mentaires (comme dans l'ASCII-art) .\n"
  "Aussi les permis Marquent une pause/Reprennent le play-back dans mIRC/Vortec.", // 0

  // StripFont->Hint
  "V�rifiez-le pour enlever des �tiquettes de fonte pour Yahoo. Vous laisse send\n"
  "une plus longue ligne de texte, mais vous devez d�pendre du default\n"
  "fonte", // 1

  // UseFile->Hint (for YahELite)
  "V�rifiez-le pour envoyer le texte via l'ordre de/textfile d'YahELite.", // 2

  // UseFile->Hint (for mIRC/Vortec)
  " UseFile  UseDLL                  Problem                         \n"
  "------------------------------------------------------------------\n"
  "   NO       NO    mIRC strips spaces, Don't use for ASCII Art     \n"
  "   NO      YES    GOOD. ALLOWS ASCII-ART, PAUSE/RESUME/BURST      \n"
  "  YES       NO    Good for ASCII-art but can't pause-play in mIRC \n"
  "  YES      YES    Problem with this, you can't use burst-play...  ", // 3

  // SendUtf8CheckBox->Hint
  "Cochez cette case pour provoquer tout le texte envoy� �\n"
  "votre chat en-client � �tre convertis d'ANSI en UTF-8", // 4
  
  // Spares
  "", // 5
  "", // 6
  "", // 7

  "Jouer canal a �t� chang� � distance ", // 8
  "la mise en arri�re � ", // 9

  // AddButton->Hint
  "Ajouter une nouvelle salle en utilisant le texte\n"
  "dans la bo�te d'�dition...\n\n"
  "Pour saisir un caract�re Unicode, tapez SES chiffres\n"
  "hexad�cimaux et appuyez sur Alt+X.", // 10

  "Toutes les chambres supprimé... Appuyez sur Annuler pour annuler!", // 11

  // ChanEditKeyDown() - add
  "Ajouté ", // 12
  "à la liste de chambre!", // 13

  // NoSpaces->Hint
  "Sur le Jeu, remplacez des espaces avec _ and\n"
  "rendez-les invisibles.", // 14

  // NSEdit->Hint
  // This character will be used to form an "invisible space".
  "Ce personnage sera utilis� pour former\n"
  "un \"espace invisible\".", // 15

  // Rooms->Hint
  "Tapez un nom de pi�ce et appuyez sur Entr�e pour l'ajouter �\n"
  "la liste. Cliquez sur la fl�che vers le bas pour afficher la liste.", // 16

  "Supprimer une pi�ce. Maj-clic\n"
  "Pour supprimer toutes les chambres...", // 17

  "Supprimé ", // 18
  " De chambre-list", // 19

  "Vous ne pouvez pas supprimer \"statut\"!", // 20

  // Form's captions and lables...

  // Sous-titre
  "Les Options de Play de texte", // 21

  // Label1
  "Le temps entre de ligne (Mme) =>", // 22

  // Label11
  "<= l'Intervalle d'�clatement (Mme) :", // 23

  // Label2
  "La Pi�ce Conversation (l'Exemple \"myroom\")"
  "(pour la plupart des clients utilisent \"�tat\" pour tester)", // 24

  // SendUtf8
  "Envoyer en tant que UTF-8", // 25

  // Label5
  "Le dossier d'int�rimaire le play", // 26

  // Label6
  "Les octets de Max pour envoyer", // 27

  // StripFont
  "FonteBande", // 28

  // UseDLL
  "UtilizDLL", // 29

  // UseFile
  "UtilizDossier", // 30

  // LineBurst
  "d'�clatementLigne", // 31

  // NoSpaces
  "AucunEspace", // 32

  // ClearRoomsButton
  "Effacer", // 33

  // ResetPathButton
  "R�initialiser", // 34

  // Cancel Button
  "r�silier", // 35

  // PaddingLabel
  "Caract�re fil", // 36

  // AddButton
  "Ajouter", // 37

  // Spares
  "", // 38
  "", // 39

  // SPECIAL!!!!!!!! DO NOT TRANSLATE!!!!!!!!!!!!!!!
  "status", // 40

  // Spares
  "", // 41
  "", // 42
  "", // 43
};
//************************************************************************
const char* FAVCOLORSMAINMENU[] =
{
  "Dossier",

  "Importation",
  "Exportation",
};
//************************************************************************
const char* FAVCOLORSDLG[] =
{
"Couleurs Pr�f�r�es", // Window Title
"Seleccione color y pulse OK", // Label
"Exemple", // List-box text
"Ajouter Actuelle",
"Ajouter Nouveau",
"supprimer",
"Sauvegarder",
"Annuler",
};
//************************************************************************
const char * STRIPDLG[] =
{
"d�pouiller", // Window Title
"Retirer des codes:", // Radiogroup caption
"", // Spares
"",
"Tous les codes", // MUST REMAIN AT INDEX 4!!!!
"Tous les codes ext�rieur Pousser/Pop",
"codes gras",
"souligner codes",
"Italiques (ou inverse vid�o)",
"FG Couleurs",
"BG Couleurs",
"toutes les couleurs",
"Toutes les polices codes",
"Pousser/Codes Pop",
"Ctrl-O",
"Tabulation",
"Page Breaks",
};
//************************************************************************
const char * MAINPOPUPMENU[] =
// Main popup menu
{
// Pop-up menu
"Espace libre",
"Original",
"Processus",
"Mettez", // (Start) StartPlay1        "Begin playing Texte to a chat client"
"-",
"Etat du texte sur Caret",
"Traitez le Titre de Chanson SwiftMiX",
"-",
"Coupe",
"Copy",
"P�te (Color)",
"P�te",
"Delete",
"-",
"Choisissez Tous",
};
//************************************************************************
const char * COLORCOPYPASTEMENU[] =
// Color paste menu
{
"Afficher la couleur",
"-",
"Color Copy",
"Coller couleur",
"Coller Couleur de fond",
};
//************************************************************************
// Main menus - Pop-Up menu is at the top
const char* MAINMENU[] =
{
"Dossier", // (File) FileMenu 0
"Nouveau...", // FileNewItem            "Clear the edit control"
"Ouvert (UTF-8)", // (Open) FileOpenItem
"Ouvert (ANSI)", // (Open) FileOpenItem
"Enregistrer...", // (Save) FileSaveAsItem
"Enregistrer Sous", // (Save As) FileSaveAsItem
"-",
"Couleurs D'Importation", // (Import Couleurs) ImportBlendCouleurs1
"Couleurs D'Exportation", // (Export Couleurs) ExportBlendCouleurs1
"-", // N14
"HTML D'Exportation", // ExportAsWebPage1
"-",
"Mise en page", // FilePageSetup
"Aper�u Imprimez", // FilePreviewItem
"Imprimez", // (Print) FilePrintItem
"-",
"Sortie", // (Exit) FileExitItem

"Outils", // (Tools) ToolsMenu 8
"�motic�nes",
"Ailes �diteur",
"-",
"Couleur de premier plan",
"La couleur de fond",
"Set Wing Couleur",
"D�finir la couleur fen�tre",
"Changer la palette de couleurs",
"Couleurs pr�f�r�es", // MenuFavoriteColors
"-",
"Police",
"Table des caract�res",
"Afficher Hex",
"Reseed al�atoire Num Gen",
"-",
"Supprimer caract�res de format",
"Strip avanc�s / espaces de fin",
"Ajuster Espaces De Fin", // Adjust Trailing Spaces
"Rejoignez lignes dans les paragraphes",
"Optimiser",

"�ditez", // (Edit) EditMenu 18
"D�gagez", // (Clear) EditClearItem "Clear the Text without disturbing the clipboard"
"D�faites", // (Undo) Undo1
"-",
"Emportez Textee", // (Cut) EditCutItem "Delete selected item"
"Copy Textee", // (Copy) EditCopyItem "Copy selected item to clipboard"
"P�te (Color)", // EditPasteColor "Paste contents of clipboard with codes"
"P�te", // (Paste) EditPasteItem  "Paste contents of clipboard"
"Choisissez tout le Textee", // (Select All) SelectAll1 "Highlight all Text"
"-",
"Rechercher", // Find
"Remplacer", // Replace
"-",
"Orthographe",

"Vue", // (View) ViewMenu 26
"Version originale", // (Original) Original1
"Version trait�e", // (Processed) RTF1
"IRC", // IRC1
"HTML", // HTML1
"RTF", // RTFSource1
"-",
"Visualiser", // Call ViewInBrowser1Click()
"-",
"Retour ligne", // WordWrap

"Jouez", // (Play) PlayMenu 32
"Mettez", // (Start) StartPlay1        "Begin playing Texte to a chat client"
"Arr�tez", // (Stop) StopPlay1          "Stop playing Texte to a chat client"
"Pause", // PausePlay1
"R�sum�", // (Resume) Resume1
"-",
"Options", // PlacezPlay1        "Placez the channel name and play speed"

"Effets", // EffetsMenu 38

"Composez",
"Texte \"bold\"(B)",
"Soulignez(U)",
"Italique(I)",
"Prot�g�(P)",
"Fin Prot�g�(p)",
"Texte Plat(O)",
"Couleur(C)",
"Type police(F)",
"Taille police(S)",
"Saut page(N)",

"Type",
"Type police",
"Taille police",
"Montagne",
"Vall�e",
"En descendant",
"Vers le Haut",
"Grand-Montagne",
"�norme-Montagne",
"Al�atoire",

"D�finir de couleurs", // Set New Colors
"remplacer la couleur", // Replace Color
"Morph Couleurs", // MorphColors1
"Alterner Couleurs", // Alternate Colors
"Alterner Lettre", // AlternateSoulignezBold1
"Incr�mentez Couleurs", // Increment Colors
"Al�atoire Couleurs", // Random Colors
"FG M�langez", // FgBlend
"BG M�langez", // BgBlend
"-",
"Couleur Fractal", // GenerateCouleurFractal1

// To add a new client, add it to the enumerated types,
// tCli and tCliID, add it here (another entry below)
// and in Main.cpp add it to GetColorizeNetClient()
// and GetInternalClient()
"&Client",
CLIENTS[0],
CLIENTS[1],
CLIENTS[2],
CLIENTS[3],
CLIENTS[4],
CLIENTS[5],
CLIENTS[6],
CLIENTS[7],
CLIENTS[8],

"Aidez", // HelpMenu
"Aidez", // Help1
"Web-Site", // wwwYahCouleuriZecom1
"-", // N3
"D�mo: D'Art", // ASCIIArtDemo
"D�mo: Textes", // DemoText
"D�mo: Textes (Ailes)", // DemoTextWings
"Document Technique", // TechDemo
"-", // N12
"Arrangements de restauration", // RestoreFactoryPlaceztings1
"-", // N11
"Informations...", // HelpAboutItem                         "Show program information"
};
//************************************************************************
// French
const char* KEYSTRINGS[TOTAL_KEY_STRINGS] =
{
"License Days: ", //0
"(Invalid License)", //1

"votre �preuve-p�riode a le begun!\n"
"pour �crire une clef achet�e de permis, cliquent\n\n"
"l'aide->installent environ nouveau Key\n\n"
"vous remercient d'essayer mon logiciel!", //2

"il y avait un probl�me validant la clef de permis!", //3
"visite ", //4
" pour acheter ce produit!", //5

"votre besoin d'obtenir une clef et un enter de permis\n"
"il afin de valider ce produit", //6

"conseil : La premi�re fois que vous ex�cutez ce programme,\n "
"vous devez avoir des droits d'acc�s d'administrateur!", //7

"placez svp votre calendrier � la date appropri�e!", //8

"votre activation a la visite d'expired.\n", //9
"� remplacer!", //10

"vous devez �crire l'address de E-mail\n"
"que vous avez employ� en demandant votre clef de permis!", //11

"E-mail: "
"m�mes que celui demandaient votre clef de permis!", //12

"votre nom d'ordinateur a pu avoir chang� le since\n"
"la derni�re fois o� vous avez employ� YahCoLoRiZe. Vous aurez besoin de to\n"
"r�installez la clef de permis ! Pour information visit:\n\n ", //13

"Discrete-Time Systems ne seront pas liable\n"
"pour aucun dommage quelconques comprenant le damages\n"
"direct, cons�cutif, fortuit, sp�cial indirect, de\n"
"ou la perte de b�n�fices, m�me si du Discrete-Time Systems\n"
"(Mister Swift) a �t� inform� du possibility\n"
"de ledit damages.\n\n"
"si vous CONVENEZ, pression oui, autrement, num�ro de pression", //14

"Nouvelle Clef De Permis �crite Avec succ�s!",//15

"YahCoLoRiZe a �t� avec succ�s activ�!", //16

"le inadmissible de clef de permis...\n"
"fonctionnant en mode restreint, certains comporte indisponible...", //17

"Cl� que vous avez entr� n'est pas valide!", //18

"(Licence illimit�e)", //19
};

//************************************************************************

// Status messages displayed while busy processing
const char* STATUS[] =
{
  "Fusion tampons...", // 0 Merging buffers
  "Chargement m�moire ruisseau...",  // 1 Loading memory-stream
  "Traitement au format RTF...", // 2 Processing to RTF format
  "Traitement au format IRC...", // 3 Processing to IRC format
  "Ajout d'effets de texte...", // 4 Adding text effect
  "Initialisation texte effet...", // 5 Initializing text-effect
  "Ancienne forme d�capage...", // 6 Stripping old formatting
  "Optimisation de texte...", // 7 Optimizing text
  "Traitement au format Yahoo...", // 8 Processing to Yahoo format
  "Traitement caract�res de texte mettent en �vidence...", // 9 Processing text-highlight chars
  "Traitement au format HTML...", // 10 Processing to HTML format
  "Nouvelle coller du texte...", // 11 Pasting new text
  "Cr�ation font-liste...", // 12 Creating font-list
  "Conversion de HTML � IRC...", // 13 Converting from HTML to IRC
};
//************************************************************************
// Color blender tab
const char* BLENDSCOPEITEMS[] =
{
// BlendScopeRadioButtons
"Word", //0
"Ligne", //1
"Condamnation", //2
"Paragraphe", //3
"S�lection entier", //4
};
//************************************************************************
const char* BLENDDIRECTIONITEMS[] =
{
// BlendDirectionRadioButtons
"====>>>>", // 0
"==>><<==", // 1
"<<====>>", // 2
"<<<<====", // 3
};
//************************************************************************
const char* TABITEMS[] =
{
// Tab-control
// If you change order, also change:
// TAB_PROCESS   0
// TAB_WIDTH     1
// TAB_MARGINS   2
// TAB_FORMAT    3
// TAB_BLENDER   4
// TAB_OPTIONS   5
// in Main.h and change the TTabSheet PageIndex
"Processus",
"Largeur",
"Marges",
"Format",
"M�langez",
"Options",
"Tabs",
};
//************************************************************************
const char* FN[] =
{
"WM_YahELiteExt", // 0
"&Process", // 1
"YahELite:class", // 2
"Colorize.chm", // 3
"Discrete-Time Systems", // 4
"TDTSColor", // 5
"colorize.tmp", // 6
"Colorize.dll", // 7
"xircon", // 8
"command", // 9
"/play -eps", // 10
"/play -p", // 11
"/play stop", // 12
"BlendColors1.bin", // 13
"TDTSTrinity", // 14
"Colorize.ini", // 15
"smileys.txt", // 16
"Smileys\\", // 17
"Dict\\", // 18
"manual.txt", // 19
"asciiart.txt", // 20
"tech.txt", // 21
"Colorize.ico", // 22
"YahCoLoRiZe", // 23 OUR_NAME
"YahCoLoRiZe", // 24 OUR_TITLE
"colorize.htm", // 25
"BlendColors1.txt", // 26
"FavColors.txt", // 27
};
//************************************************************************
const char * DS[TOTALSTRINGS] =
{
// [0]
"",
// [1]
"RegisterWindowMessage il n'a pas fonctionné.",

// ImportAsciiButton->Hint = XX->Strings[2];
"Gauche-clic POUR IMPORTER l'ordinaire-texte\n"
"Droite-clic POUR EXPORTER l'ordinaire-texte\n\n"
"Format: 10 Couleurs (hex):\n"
"rrggbb rrggbb rrggbb...",

// XX->Strings[3];
"",

// CheckBox2->Hint = XX->Strings[4];
"UnChoisi � avec de processus de Texte \"Effets\"\n"
"rev�rifiez-alors le, commutez la vue � IRC et � maintenant\n"
"retraitez le Texte pour ajouter des fronti�resailes.",

// PackLines->Hint = XX->Strings[5];
"Placez ceci pour forcer la s�paration de paragraphe � une ligne.",

// CheckBox1->Hint = XX->Strings[6];
"Ne choisissez pas ceci pour garder l'original lignes.\n"
"Choisissez ceci pour serrer le texte.",

// LeftJustify->Hint = XX->Strings[7];
"Placez ceci pour aligner le texte sur la gauche-marge.",

// ExtendPalette->Hint = XX->Strings[8];
"Cochez cette case pour �tendre le nombre de couleurs par d�faut\n"
"au-del� de 16 pour les futurs r�seaux IRC et les clients. Vous\n"
"pouvez modifier les couleurs �tendues dans le fichier Colorize.ini.",

// Process->Hint = XX->Strings[9];
"cliquez le bouton de souris droit sur web-site\n"
"pour choisir les couleurs que vous voyez au dessus.",

// BlendScopeRadioButtons->Hint = XX->Strings[10];
"Choisit la port�e du m�lange dans un bloc de texte choisi.",

// BlendDirectionRadioButtons->Hint = XX->Strings[11];
"Choisit la direction de se m�langer.",

// RGBThresholdEdit->Hint = XX->Strings[12];
"Placez ce plus haut pour �viter d'envoyer trop de Couleur-donn�es.",

// XX->Strings[13];
"Supprimer tous les fichiers installés?",

// ResolveToPaletteCheckBox->Hint = XX->Strings[14];
"choisissez ceci pour garder une vue pr�cise : WYSIWYG.",

// CouleurBlenderPrePlacezPanel->Hint = XX->Strings[15];
"Bouton gauche de souris : aux arrangements de charge.\n"
"Bouton droit de souris : pour sauver des arrangements.",

// ImportButton = XX->Strings[16];
"Bouton gauche de souris : IMPORTATION\n"
"Bouton droit de souris : EXPORTATION.",

// Borders = XX->Strings[17];
"Active le dessusfronti�res inf�rieures une fois choisi.",

// Wingdings = XX->Strings[18];
"Active des ailes une fois choisi.",

// AutoDetectEmotes = XX->Strings[19];
"D�tecte des �motion-codes une fois choisi.",

// PlayOnCR->Hint = XX->Strings[20];
"placez ceci pour serrer automatiquement\n"
"\"processus \"bouton et automobile-jeu dans\n"
"causer-pi�ce quand vous appuyez sur la touche\n"
"de p�n�trer dans.",

"Couleurs RVB ne sont pas autoris�s pour le chat IRC-clients. Essayez\n"
"de s�lectionner client-> Trinity pour permettre couleurs RVB.", // 21

// AddCouleurCheckBox->Hint = XX->Strings[22];
"Placez ceci pour ajouter la couleur\n"
"au texte quand vous serrez : Processus",

"", // 23

"Autres couleurs", // 24 Alternate Colors
"Al�atoire couleurs", // 25 Randomize Colors

"Press to pause text-play.", // 26

// ProcessButton->Hint = XX->Strings[27];
"convertissez le texte accentu� en a\n"
"le format de couleur utilis� dans causent-programes.",

// PlayButton->Hint = XX->Strings[28];
"Serrez pour jouer le texte dans la causer-pi�ce.",

// StopButton->Hint = XX->Strings[29];
"Serrez pour arr�ter le texte-jeu.",

// ResumeButton->Hint = XX->Strings[30];
"Serrez pour reprendre le texte-jeu.",

// ForegroundCouleurPanel->Hint = XX->Strings[31];
"Bouton gauche de souris : to Placez Foreground Couleur\n"
"Bouton droit de souris : pour montrer des Couleur-codes de RVB.",

// BackgroundCouleurPanel->Hint = XX->Strings[32];
"Bouton gauche de souris : to Placez Background Couleur\n"
"Bouton droit de souris : pour montrer des Couleur-codes de RVB",

// WingColorPanel->Hint = XX->Strings[33];
"Bouton gauche de souris : pour placer l'aile-couleur\n"
"Bouton droit de souris : pour montrer des couleur-codes de RVB.",

// PlayOnCX->Hint [34]
"Cocher pour recevoir et traiter � distance\n"
"texte (comme la commande /CX de IceChat).",

"Merci pour essayer mon logiciel!", // 35
"Ouvrez Le Dossier", // 36
"La conversion a échoué", // 37
"Ne peut pas charger le dossier...", // 38
"Économiser Le Dossier", // 39
"Aucun nom de fichier indiqué.", // 40
"La conversion a échoué", // 41
"Ne peut pas sauver le dossier...", // 42

"choisi : Outils->Éditez Ailes, puis clic \"côtés\"\n"
"ou \"frontières dessus et bas \".", // 43

"Choisi : Outils->Éditez Ailes, puis\n"
"cliquez les checkboxes ailes que vous préférez.", // 44

"Il n'y a aucun Texte à traiter.", // 45

"Tout Auto-set pour Paltalk?\n"
"(Gauche-justifier, auto-linesize, non-marges,\n"
"Police Tahoma, aucun-frontières, BG-couleur est blanc)", // 46

"Appuyez sur pour lire le texte dans la salle de chat.\n"
"(maintenez la touche Maj enfoncée et cliquez pour envoyer du texte\n"
"à Paltalk sans affichage dans la salle.)", // 47

// Margins On/Off Checkbox Hint
"Cochez cette case pour mettre toutes les marges de texte ON.\n"
"Décochez pour tourner toutes les marges de texte OFF.", // 48

"Attention: Vous ne pouvez pas modifier le texte en mode word-wrap!", // 49

// After Optimizing you may not be able to Undo previous
// changes. Continue?
"Après Optimisation vous ne pouvez pas être en mesure de\n"
"Nouvelle précédente changements. Continuer?", // 50

"Aviez-vous l'intention d'exporter uniquement le texte s�lectionn� en tant que page Web�?\n"
"Si ce n'est pas le cas, cliquez sur \"non\" puis cliquez n'importe o� dans votre document "
"pour d�s�lectionner le texte...", // 51

"Incapable de traiter :", // 52
"", // 53
"Traitement de textes avorté par l'utilisateur", // 54
"N'a pas pu remplacer la Couleur-table de rtf !", // 55
"N'a pas pu localiser la couleur-table de rtf !", // 56
"Erreur de traitement de textes dans la conversion de rtf", // 57
"", // 58
"Retourner-code inconnu", // 59
"Erreur dans : SkipSmileys()", // 60
"Ligne-taille accrue à : ", // 61
"Marge changée à : ", // 62
"Couleur Premier", // 63

"avertissant : vous avez placé la couleur de premier plan\n"
"les mêmes que la couleur de fond !", // 64

"Couleur Fond", // 65

"avertissant : vous avez placé la couleur de fond\n"
"les mêmes que la couleur de premier plan !", // 66

"avertissant : vous avez placé la couleur de fond\n"
"les mêmes que la couleur d'aile !", // 67

"Couleur d'aile", // 68

"avertissant : vous avez placé l'aile-couleur\n"
"les mêmes que la couleur de fond !", // 69

"Appuyez sur Echap pour quitter...", // 70

"avertissant : La causerie d'IRC ne peut pas manipuler le fait sur commande\n"
"utilisations de YahCoLoRiZe de codes. Éteint mélangez avant\n"
"le processus et le mélangeur commande...", // 71

"Altern� caract�re", // 72

"Modification de la police nécessite un changement à la\n"
"Affichage de texte original et le retraitement. Toute modification\n"
"vous avez fait sera perdu. Continuer?", // 73

// Replace Color Dialog Help
"Remplacer couleur est pratique si vous avez un texte existant avec des effets déjà\n"
"ajouté, mais vous avez juste besoin de changer une couleur à l'autre dans la sélection\n" 
"ou dans l'ensemble du document. Contrairement Définir de nouvelles couleurs, Remplacement\n" 
"de couleur laisse toutes les autres couleurs pré-existantes intact.\n\n" 
"À l'entrée, la première De et couleurs sont réglés comme les couleurs\n" 
"au début de la sélection. Vous pouvez cliquer droit sur une couleur à copier/coller\n"
"il d'une case à l'autre. Gauche-cliquez sur une boîte de couleur pour changer sa couleur.\n\n"
"*Astuce: Avant de sélectionner le texte que vous voulez changer la couleur, vous pouvez\n" 
"couleurs de copie à utiliser à partir de n'importe où dans le document en sélectionnant\n" 
"une partie de son texte et en choisissant droit cliquez sur Copier. Ensuite, vous pouvez\n"
"sélectionner votre zone de remplacer couleurs, choisissez Effets->Remplacement de couleur\n"
"et faites un clic droit Collez le copié plan ou la couleur de fond dans le Pour ou De\n"
"couleur-boxs. :-)", // 74

"Aller à l'onglet Client et choisir Trinity ou\n"
"YahELite pour accéder mélange de couleurs!", // 75

"Dans la conversation d'IRC vous pouvez seulement mettre l'Audacieux, Souligner, Italics\n"
"les attributs de fonte. Mettez la couleur de fonte en claquant la couleur-panels\n"
"à l'étiquette de Processus... L'italique est la VIDÉO CONTRAIRE dans IRC!", // 76 

"Le plus grand nombre de caractères à choisir est 160 !", // 77
"Vous devez choisir texte pour employer cette fonction !", // 78

"Vous êtes coller du texte qui contient la couleur de fond\n"
"dans le texte sans couleur de fond définie.\n\n"
"Supprimer les couleurs de fond du texte que vous collez?", // 79

"Il n'y a rien à imprimer !", // 80

"Imprimeur Non trouvé... Vérifiez pour être a sûr\n"
"l'imprimeur de défaut est placé pour votre ordinateur", // 81

"Le générateur de nombre aléatoire re-a semé !", // 82

"", // 83

"Texte trop long.", // 84

"", // 85

"Remplacé ", // 86
" mots mal orthographiés", // 87

"Vous devez être un administrateur pour désinstaller YahCoLoRiZe!", // 88

"Arrangements de YahCoLoRiZe supprimés !...Sortir", // 89

"Uncheck \"Auto-Blend\"\n"
"(étiquette de format) pour permettre", // 90

"Largeur", // 91

"Des Arrangements De Défaut Ont été reconstitués !", // 92

"j'ai placé cette version de mon programme pour remettre à zéro tous de\n"
"les arrangements de YahCoLoRiZe. Désolé, mais ceci une fois il\n"
"n'a pas pu être aidé ;) - dxzl", // 93

"Vieille Version Détectée ! Économiser de vieux arrangements ?", // 94
"Erreur dans: ", // 95
"N'a pas pu sauver des valeurs d'enregistrement", // 96
"Nombre lignes", // 97
"largeur", // 98

"Code de sécurité de lecture d'Erreur d'enregistrement ! :  RegOpenKeyEx()\n"
"Vous devez réinstaller YahCoLoRiZe... ;)", // 99

"Gauches faites un déclic pour le compte de ligne...", // 100

"AVERTISSANT ! ! ! Ce programme (Colorize.exe) n'est pas la version\n"
"a à l'origine installé.  Ne peut pas vérifier l'authenticité de.Dossier .EXE !", // 101

"incapable de valider, de sécurité-code\n"
"employez-vous une vieille version de Windows ?", // 102

"Incapable de calculer le code de sécurité !", // 103
"Code De Sécurité: ", // 104

"(comparez ce code au code sur web-site.\n"
"les codes devraient être identiques. Si pas, la version vous\n"
"ayez peut avoir été changé, ou la version sur le site Web\n"
"a été changé par quelqu'un sans autorité pour faire ainsi ! )", // 105

"Incapable de s'ouvrir: ", // 106

"", // 107
"", // 108
"", // 109
"", // 110

"Redémarrez votre chat en client, puis essayez à nouveau...\n"
"Lecture ou vous pouvez besoin de vérifier \"PlayOnCX\"\n"
"dans l'onglet Options ;)", // 111

"vous devez dactylographier une commande dans Client de jouer le votre\n"
"Texte dans la salle.  Dans le type de YahELite le suivant\n"
"commande, et alors le coup entrent dans :\n \n"
"/extend TDTSColor YahCoLoRiZe\n\n"
"après ceci, le message \"Prolongation Active\"\n"
"devrait montrer dans la causer-fenêtre. Serrez alors le vert\n"
"bouton de jeu encore.", // 112

"Avertissement : le jeu de ceci dans la salle\n"
"envoyez le mauvais texte. Vous pouvez vouloir à\n"
"serrez le \"PROCESSUS\" d'abord.  Décommandez le jeu ?", // 113


"est sur la limite fixée dans Play->Options!\n\n"
"Vue->Original et essai de clic retraitant...\n"
"ou ensemble \"Ligne-taille Maximum \"à un plus petit nombre...\n"
"ou AUGMENTEZ le nombre de seuil de RVB dans l'étiquette de mélange.", // 114

"Ligne", // 115

"Il n'y a rien à jouer... ^_^", // 116
"Erreur de préparation texte pour la lecture...", // 117

"", // 118

"s'assurent tous les deux dossiers Colorize.DLL et Xtcl.DLL \n "
"soyez dans le même annuaire que YahCouleuriZe.exe ", // 119

"", // 120
"", // 121
"", // 122
"", // 123
"", // 124

"Erreur envoyant la commande de jeu au mIRC", // 125
"Ne peut pas trouver : ", // 126
"Aucune fonction de pause : ", // 127

"Le changement de client reguires dégageant tout le texte \n"
"Appuyez bien pour vous éclaircir.", // 128

"Aucune fonction de résumé : ", // 129

"Le rendu de ceci au rtf prendra du temps. Vous pouvez\n"
"jouez toujours la version que nous avons maintenant...\n"
"Aller de subsistance ?", // 130

"Ne peut pas charger: ", // 131
"Ne peut pas trouver: Colorstop()", // 132

"", // 133

"Adding an effect is not allowed in this View!", // 134

"Merci d'essayer mon logiciel\n\n"
"Pour effacer les icônes YahCoLoRiZe,\n"
"le claquement juste eux et choisit Effacent!", // 135

"Non installez YahCoLoRiZe ?", // 136

"opération Utilisateur-décommandée !", // 137
"Une erreur s'est produite dans le Texte-traitement", // 138
"Aucun Texte n'a été choisi, en choisissez !", // 139

"Chevauchements de sélection Autres effets...\n"
"Ce message arrive quand vous avez un\n"
"protéger la zone avec unmached PUSH/POP\n"
"codes intégrés dans un texte de sélection.", // 140

"Retourner-code de traitement inconnu", // 141

"Mise en page", // 142 page setup
"Imprimez", // 143 Print

"", // 144
"", // 145
"", // 146

"Les bords de frontière ne seront pas même après le traitement.\n"
"Arrêtez Les Frontières ?", // 147

"Les bords de frontière ne seront pas égaux\n"
"après traitement. Arrêt ?", // 148

"BlenCouleurs object is missing...", // 149

"Le code d'erreur est: ", // 150
"Dossier de lecture d'erreurs...", // 151

"Bon clic sur au moins DEUX mélanger-boutons\n"
"Vous devez avoir un minimum de DEUX vous mélangez-Couleurs permis !", // 152

"Le problème s'est produit dans \"CreateBlendEngine()\"", // 153

"Préréglez Couleurs ont été changés\n"
"sans économie. Économiser eux maintenant ?", // 154

"", // 155

// SaveDialog->Title = XX->Strings[156];
"Couleurs De M�langeur D'Exportation", // 156

"", // 157

"Ne peut pas sauver le dossier...", // 158

// SaveDialog->Title = XX->Strings[159];
"L'exportation ASCII vers le courant a préréglé", // 159

"Le dossier existe, recouvrez ?", // 160
"Incapable d'ouvrir le dossier pour couleur-exportez", // 161
"Incapable d'exporter des couleurs", // 162

// OpenDialog->Title = XX->Strings[163];
"L'importation ASCII vers le courant a préréglé", // 163

"Incapable d'ouvrir le dossier pour couleur-importez", // 164
"Incapable d'importer des couleurs", // 165

// OpenDialog->Title = XX->Strings[166];
"Mélangeur-couleurs d'importation", // 166

"Désolé, dossier non lisible...", // 167

"R�initialiser?\n\n"
"Avant de restaurer les valeurs par défaut, vous pouvez\n"
"exporter vos ailes personnalisées et/ou mélanger-couleurs...\n"
"Etes-vous sûr de vouloir restaurer les valeurs par défaut?", // 168

"Ce préréglez est vide...\n"
"droite de clic de sauver des couleurs montrées.", // 169

"YahCoLoRiZe peut afficher un fichier .rtf, mais ne peut\n"
"le convertir au format de code natif. YahCoLoRiZe IRC travaille\n"
"avec normalement. Il n'y a aucune convertisseur � cette heure!", // 170

"Économisé pour prérégler ", // 171

"Avertissement : faire ceci vous donnera le RVB pur ; cependant,\n"
"vous perdrez l'exactitude d'IMPRESSION CONFORME À LA VISUALISATION ! Êtes-vous sûr ?", // 172

"Le réglage des valeurs plus basses que ", // 173
" peut\n inonder la salle avec des couleur-codes !", // 174

// Border-Color dialog
"couleur de Fronti�re-fond", // 175
"Employez le plein spectre de RVB ?", // 176
"R�vision : ", // 177
"La couleur de Forground est illégale : ", // 178
"La couleur de fond est illégale : ", // 179
"annuler la derniére \"processus\"?", // 180
"", // 181

"Insérer émoticône raccourci ...", // 182

"", // 183
"", // 184
"", // 185
"", // 186
"", // 187
"", // 188
"", // 189
"", // 190
"", // 191
"", // 192
"", // 193
"", // 194
"", // 195

// SwiftMixSync Hint
"Cochez cette case pour recevoir SwiftMix informations\n"
"de synchronisation de la lecture.", // 196

// Blender-Tab Hint "Blender->Hint" (Used for color-buttons)
"Left-clic: Choisissez un couleur-panneau\n"
"Left-Double-clic: Choisissez la couleur du panneau\n"
"Right-clic: Basculez le couleur-panneau choisi DESSUSOUTRE DE\n"
"Wheel-Up/Vers le bas: Obscurcissez ou �clairez la couleur choisie\n"
"Wheel-clic: �clat d'original de restauration", // 197

// Right-click in title-bar to set the colors you see!
"Faites un clic droit dans la barre de titre pour\n"
"d�finir les couleurs que vous voyez!", // 198

// Checkbox-Captions...
// LeftJustify->Caption
"La Gauche Justifient", // 199
// PackText->Caption
"Texte de compresse", // 200
// not used
"", // 201
// PackLines->Caption
"Lignes De Compresse", // 202
// Borders->Caption
"Fronti�res", // 203
// Wingdings->Caption
"Ailes", // 204
// AutoDetectEmotes->Caption
"Auto Trouvaille Emotes", // 205
// PlayOnCR->Caption
"Automobile-Jeu CR", // 206
// SwiftMixSync->Caption
"SwiftMiX Sync", // 207
// ExtendPalette->Caption
"Extend Palette", // 208
// ImportBlenderLabel->Caption
"dans/hors de M�langeur", // 209
// RGBThresholdLabel->Caption
"Seuil de RVB", // 210

// Right click me!
"Cliquez-droit sur moi!", // 211

// OK to clear the text and a new client-mode?
"OK pour effacer le texte et un nouveau client en mode?", // 212

"S�lectionnez type police", // 213
"Choisir taille police", // 214

"", // 215
"", // 216
"", // 217
"", // 218
"", // 219

// WingColorLabel->Caption
"Ailes", // 220

"Ce préréglez est vide...", // 221

"Vous ne trouvez pas...", // 222
"S'il vous plaît réinstaller YahCoLoRiZe...", // 223
"Client: ", //224

// PlayOnCX->Caption
"Automobile-Jeu CX", // 225

"Fichier corrompu...", // 226

"Préparation à désinstaller YahCoLoRiZe, Si une invite de commandes\n"
"Windows demande l'autorisation d'exécuter la commande Shell Microsoft\n"
"cliquez sur \"Oui\" et lui accorder l'autorisation d'exécuter, sinon,\n"
"Désinstaller ne sera pas acheva ...", // 227

"Le travail non enregistré, à proximité de toute façon?", // 228

"Texte de premier plan transparent ne sera pas restituer correctement\n"
"en HTML, permet de toute façon?", // 229

"", // 230
"", // 231

"Largeur languette", // 232
"Convertir les tabulations en espaces", // 233

"V�rification cela ins�rer des espaces plut�t que des"
"caract�res de tabulation lorsque vous appuyez sur TAB", // 234

"Aplatir les onglets processus", // 235

"S�lectionnez cette option pour remplacer les tabulations avec\n"
"des espaces �quivalents lors du traitement de texte.", // 236

"Strip Tabs sur le processus", // 237

"S�lectionnez cette option pour remplacer les tabulations par\n"
"un espace simple lors du traitement de texte.", // 238

"", // 239
"", // 240
"", // 241
"", // 242

// AsIsButton Hint and Label
"Montrez", // 243 AsIsButton Label

"Rend le texte \"comme est\"sans fronti�res, ailes\n"
"ou suppl�mentaire de formatage de texte d'aucune sorte.\n\n"
"(Push/Pop r�gions texte en incrustation sont affich�s\n"
"en caract�res barr�s!)", // 244 Hint

// Auto-linewidth (Width tab)
"Auto", // 245

"D�finit la longueur des lignes � la longueur de la plus\n"
"longue ligne de texte", // 246

// Width of text plus wings (Width tab)
"Largeur ligne", // 247
"Longueur d'une ligne de texte. Cela comprend les ailes,\n"
"mais ne comprend pas la marge ou sur le c�t� des fronti�res.", // 248

// Left margin (Margins tab)
"gauche", // 249
"Montant de l'espace entre la bordure de gauche\n"
"et le texte", // 250

// Indent (Width tab)
"Tiret (+/-)", // 251
"Paragraphe tiret (jeu n�gatif � faire une\n"
"liste num�rot�e)", // 252

// Right margin (Margins tab)
"droite", // 253
"Montant de l'espace entre la bordure de droite\n"
"et le texte", // 254

// Auto-lineheight (Width tab)
"Auto", // 255
"Hauteur des bo�tes est par les paragraphes", // 256

// Lines per box (Width Tab)
"hauteur", // 257
"Les lignes de texte par bo�te: 0 = off", // 258

// Spacing between boxes (Width Tab)
"espacement", // 259
"L'espacement entre les cases: 0 = un seul foss�", // 260

// # blank lines at top (Margins Tab)
"sup�rieure", // 261
"Nombre de lignes vides entre la bordure et le texte", // 262

// # blank lines at bottom (Margins Tab)
"inf�rieure", // 263
"Nombre de lignes vides entre la bordure inf�rieure et\n"
"le texte", // 264

// Margins On/Off Checkbox
"Allumez/�teignez", // 265
};
//---------------------------------------------------------------------------
const wchar_t* HTMLCODES[] =
{
  L"&amp;",
  L"&#39;",
  L"&quot;",
  L"&nbsp;",
  L"&gt;",
  L"&lt;",
  L"&cent;",
  L"&curren;",
  L"&divide;",
  L"&copy;",
  L"&micro;",
  L"&pound;",
  L"&euro;",
  L"&yen;",
  L"&trade;",
  L"&sect;",
  L"&reg;",
  L"&para;",
  L"&middot;",
  L"&plusmn;",
  L"&iexcl;",
  L"&sect;",
  L"&brvbar;",
  L"&uml;",
  L"&ordf;",
  L"&laquo;",
  L"&not;",
  L"&macr;",
  L"&deg;",
  L"&sup2;",
  L"&sup3;",
  L"&acute;",
  L"&cedil;",
  L"&sup1;",
  L"&ordm;",
  L"&raquo;",
  L"&frac14;",
  L"&frac12;",
  L"&frac34;",
  L"&iquest;",
  L"&times;",
};
//---------------------------------------------------------------------------
// The index of the char in this string looks up its HTML replacement
// string in the table above.
const wchar_t* HTMLCHARS = L"&\'\",><�����������������������������������";
//------------------------------------------------------------------
