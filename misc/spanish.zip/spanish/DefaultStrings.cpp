#include <vcl.h>
#include <Controls.hpp>
#include "Main.h"
// Include header files common to all files before this directive!
#pragma hdrstop

//************************************************************************
// This table allows us to maintain a constant index across various
// platforms over the IRC network, independant of the fonts on a given machine.
const char* FONTS[] =
{
// Internal fonts for which we embed a code-index to represent it in
// the IRC text... 1-99 (0 is reserved to indicate the default font)
// ok to add as many as you want... but change FONTITEMS in the header file!
//
// Completely case independant...
"Courier New", // 1 (do not change) USER_DEF_TYPE
"Tahoma", // 2 (do not change) PALTALK_DEF_TYPE
"Arial",
"Arial Black",
"Arial Narrow",
"Arial Unicode MS",
"Batang",
"Batangche",
"Book Antiqua",
"Bookman Old Style", // 10
"Bookshelf Symbol 7",
"Browallia New",
"Browalliaupc",
"Buxton Sketch",
"Calibri",
"Calibri Light",
"Cambria",
"Cambria Math",
"Candara",
"Century", // 20
"Century Gothic",
"Comic Sans MS",
"Consolas",
"Constantia",
"Corbel",
"Cordia New",
"Cordiaupc",
"Courier",
"Daunpenh",
"David", // 30
"Default",
"Dilleniaupc",
"Dokchampa",
"Euphemia",
"Fangsong",
"Fixedsys",
"Franklin Gothic Medium",
"Freesiaupc",
"Gabriola",
"Garamond", // 40
"Gautami",
"Georgia",
"Gelvetica",
"Impact",
"Irisupc",
"Iskoola Pota",
"Jasmineupc",
"Javanese Text",
"Kaiti",
"Kalinga", // 50
"Kartika",
"Khmer UI",
"Kodchiangupc",
"Kokila",
"Lao UI",
"Latha",
"Leelawadee",
"Lucida Console",
"Lucida Sans Unicode",
"Malgun Gothic", // 60
"Mangal",
"Marlett",
"Meiryo",
"Meiryo UI",
"Miriam",
"Miriam Fixed",
"Modern",
"Mongolian Baiti",
"Moolboran",
"Mt Extra", // 70
"Mv Boli",
"Myanmar Text",
"Nyala",
"Palatino Linotype",
"Plantagenet Cherokee",
"Raavi",
"Roman",
"Script",
"Sketchflow Print",
"Small Fonts", // 80
"Symbol",
"System",
"Terminal",
"Times New Roman",
"Traditional Arabic",
"Trebuchet MS",
"Verdana",
"Webdings",
"Wingdings",
"Wingdings 2", // 90
"Wingdings 3",
"@Arial Unicode MS",
"@Batang",
"@Dotum",
"@Kaiti",
"@Malgun Gothic",
"@Meiryo UI",
"@Mingliu",
"@Mingliu_hkscs", // 99
};
//************************************************************************
const char* VIEWS[] =
{
  // ViewStatus Text Display
  "visi�n: Original",
  "visi�n: Procesado",
  "visi�n: Irc",
  "visi�n: HTML",
  "visi�n: Rtf",
  "visi�n: Off",
  "visi�n: Unknown",
};
//************************************************************************
const char* CLIENTS[] =
{
  // ClientStatus Text Display
  "YahELite",
  "mIRC",
  "IceChat",
  "Hydra",
  "LeafChat",
  "Vortec",
  "XiRCON",
  "Paltalk",
  "Trinity",
};
//************************************************************************
const char* WINGEDITMAINMENU[] =
{
  "Opciones",

  // These Wings are in "ANSI UTF-8" a backslash
  // escape is in front of the " or \ char.
  "Inserte Wingding",
  "<~*-,._.,-*~'^'~*-,",
  ",-*~'^'~*-,._.,-*~>",
  "´¯`~°³²¹ºª¤", // "��`~�������"
  "¤ªº¹²³°~´¯`", // "�������~��`"
  "\"°º©o., ", // "\"���o., "
  " ,.o©º°\"", // " ,.o���\""
  "««", // "��"
  "»»", // "��"
  "<-.¸¸.·´¯", // "<-.��.���"
  "¯`·.¸¸.->", // "�`�.��.->"
  "03.;'``~<04@",
  "04@03>~``';.",
  "04¶09¦10+11) ", // "04�09�10+11) "
  " 11§10:09¬04>", // " 11�10:09�04>"
  "`·.<º)))><.·´", // "`�.<�)))><.��"
  "`·.><(((º>.·´", // "`�.><(((�>.��"
  "3¤~»}4@3{«~¤", // "3�~�}4@3{�~�"
  "«¤´¤»¥«¤´¤»¥«¤´¤»", // "�����������������"
  " Këw£ ", // " K�w� "
  "»4¡«»10¡«»12¡«", // "�4���10���12��"
  "02,01 04\\01,04\\08\\04,08\\/08,04/01/04,01/01 ",

  "-",
  "Relleno De la Diseñar-Ventana Principal",
  "-",
  "(C) De color",
  "(F) Tipo fuente",
  "(S) Tamaño fuente",
  "(B) Negrita",
  "(I) La cursiva",
  "(U) Subrayado",
  "(O) Texto sin formato",
  "(P) Protegido",
  "(p) Fin de Protegida",

  "-",
  "Optimize",

  "-",
  "Exportación Al Texto-Archivo",
  "Importación Del Texto-Archivo",
  "-",
  "ahorre y salga",
  "parado",

  "visión", // View Menu

  "RTF (Color Text Edit)",
  "IRC (Plain Text Edit)",

  // Help
  "ayudar",
};
//************************************************************************
const char* EDITPOPUPMENU1[TOTALEDITPOPUPMENU1] =
{
  "Undo All Wing-Edits",
  "-",
  "Add New Wing-Pair",
  "Import From Main Design Window",
  "-",
  "Cut",
  "Edit Selected Wing",
  "-",
  "Copy",
  "Paste",
  "-",
  "Borrar toda la lista",
};
//************************************************************************
const char* EDITPOPUPMENU2[] =
{
  "claro", // Clear
  "deshacer",
  "-",
  "Cut",
  "Copy",
  "Paste",
  "borrar",
  "-",
  "Seleccionar todo",
  "-",
  "Cambia visualización",
  "-",

  "Agregar efectos de texto",

  "Código De Color (Crtl-K)",
  "Tipo fuente",
  "Tamaño fuente",
  "En negrilla (Ctrl-B)",
  "Italics (Ctrl-R)",
  "Raya (Ctrl-U)",

  "-",
  "Guardar y salir",
  "Salir sin salvar",
};
//************************************************************************
const char* COLORDIALOGMSG[] =
{
  "Vert Blend", //0
  "RGB Color", //1
  "Horiz Blend", //2
  "Random", //3
  "Transparent", //4
  "Cancel", //5
  "", //6
  "", //7
  "", //8
  "", //9
  "color del primero plano", // 10
  "color del fondo", // 11
  "efecto: Primero plano Que se alterna", // 12
  "Morph Colores", // 13
  "Reemplazar Colores", // 14
  "", // 15
  "", // 16
  "Effect: Underline Color A", // 17
  "Effect: Underline Color B", // 18
};
//************************************************************************
const char* WEBEXPORTMSG[] =
{
  "", //0
  
  "Web Page Top Margin (p�xeles)", //1
  "Web- Margen Izquierda (p�xeles)", //2
  "Web -page BG Color", //3

  "Haga clic para seleccionar el color de fondo\n"
  "para su nueva p�gina web...", //4

  "Desactive esta opci�n si su est�n generando una p�gina web completa.\n"
  "Marque esta copiar c�digo HTML al Portapapeles de Windows.\n"
  "A continuaci�n, puede pegar c�digo HTML en otros programas como el E -Mail.", //5

  "Marque esta opci�n para utilizar un enlace web a una imagen\n"
  "para la p�gina web que generamos.", //6

  "Marca esta casilla para evitar que la imagen de fondo\n"
  "de desplazamiento junto con el texto.", //7

  "Marque esta opci�n para incluir la etiqueta de autor META!", //8

  "Marque esta opci�n para incluir la etiqueta de title META!", //9

  "Marque esta opci�n para generar un bot�n de p�gina HOME!", //10

  "Repetir: repite la imagen horizontal y verticalmente.\n"
  "Repetir-X: repite la imagen s�lo horizontalmente.\n"
  "Repetir-Y: repite la imagen veritcally s�lo.\n"
  "No-Repetici�n: muestra la imagen tal como est�.\n\n"
  "(Nota: Si no-repeat se establece, el pisition imagen es\n"
  "establecido por los controles deslizantes en la parte\n"
  "superior de este cuadro de di�logo 0%-100%)", //11

  "Active esta opci�n para forzar la inserci�n de espacios de no\n"
  "separaci�n al final de las l�neas. Esto s�lo deber�a ser necesario\n"
  "para la compatibilidad con navegadores antiguos que ignoran el\n"
  "estilo de espacio en blanco.", // 12

  "", // 13
  "", // 14
  "", // 15
  "", // 16

  "uso T�tulo", // 17
  "Nombre Uso del autor", // 18
  "Haga Bot�n Inicio", // 19
  "Espacios Insertar no separaci�n", // 20
  "Estilo Blanco-Espacio", // 21

  "", // 22
  "", // 23
  "", // 24
  "", // 25

  "Altura L�nea: ", // 26
};
//************************************************************************
const char * EDITMSG[] =
{
  // T�tulo
  "Corrija Fiestas animadas", // 0

  // Label5
  "Dejado", // 1

  // Label6
  "Derecho", // 2

  // Label7
  "Cumbre y Fronteras de Fondo", // 3

  // Label8
  "Izquierda", // 4

  // Label9
  "Derecha", // 5

  // Label10
  "Fondo Fronterizo: Color:", // 6

  // TopBottomBorders
  "Permitido", // 7

  // SideBorders
  "Lados Permitieron", // 8

  // Button1
  "&Save y Salida", // 9

  // Button2
  "Mapa de Car�cter", // 10

  // Button3
  "Redactor de Fuente", // 11

  // Edit1->Hint
  "Pulse ENTER para salir y guardar.\n"
  "Pulse ESC para salir sin guardar.\n"
  "CTRL + T Cambia la vista.\n"
  "Haga clic en el men� pop-up.", // 12

  // LeftWingsListBox->Hint, RightWingsListBox->Hint (not in edit-mode)
  "Haga doble clic en un elemento para editarlo.\n"
  "Haga clic en el men� emergente.\n"
  "Marque la casilla para permitir que el ala-pair.\n"
  "Pulse la tecla ESC para abortar.", // 13

  // TopBottomEdit->Hint, LeftSideEdit->Hint, RightSideEdit->Hint
  "Haga clic izquierdo para editar.", // 14

  // LeftWingsListBox->Hint, RightWingsListBox->Hint (in Edit-mode only)
  "Haga clic izquierdo para editar.\n"
  "Haga clic derecho en el men� emergente.", // 15

  // Spares
  "", //16
  "", //17
  "", //18
  "", //19

  // General messages...

  // Import instructions
  "Para importar, para diseñar un ala de UNA SOLA LÍNEA por lo general VENTANA. Press\n"
  "El PROCESO y añade cualquier efecto que usted puede querer. En el redactor de ala, \n"
  "haga clic la caja que usted quiere importar en (Alas izquierdas o Alas derechas), \n"
  "Derecho de chasquido de aparecer este menú y chasquido esta selección de menú otra vez.", // 20

  "Error que Importa Alas ...", // 21

  "Alas de Exportación Como Texto", // 22

  "Error que Exporta Alas ...", // 23

  "Operación no permitida en este View!", // 24
  "Debe seleccionar texto para realizar esta operación!", // 25

  "Haga clic en un borde para editarlo.\n\n"
  "Haga doble clic en un ala para editarlo.\n\n"
  "Haga clic derecho en la ventana de edición para\n"
  "ver el menú pop-up.\n\n"
  "Haga clic en \"View\" para editar los códigos IRC primas.\n\n"
  "Haga clic en \"Opciones\" para exportar/importación alas,\n"
  "o cambiar la parte seleccionada de la\n"
  "color ala, etc.\n\n"
  "También se puede diseñar un ala en la principal\n"
  "YahCoLoRiZe ventana y luego importarlo a través de\n"
  "\"Opciones->Insertar desde la ventana principal del diseño\".", // 26

  "Ala-lista es corrupto ... repararlo", //27
  "Haga clic o doble clic en un elemento para editarlo ...", //28

  // Spares
  "", //29
  "", //29

  // DO NOT TRANSLATE THE FOLLOWING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  "charmap.exe", //30
  "eudcedit.exe", //31

  // Spares
  "", //32
  "", //33
  "", //34
};
//************************************************************************
const char* REPLACEDLGMAINMENU[] =
{
  "Insertar",

  "(C) De Color",
  "(F) Tipo fuente",
  "(S) Tamaño fuente",
  "(B) Negrita",
  "(I) La cursiva",
  "(U) Subrayado",
  "(O) Texto sin formato",
  "(P) Protegido",
  "(p) End Protegido",
  "(N) Page Break",

  "Corrija", // EditMenu

  "Claro",
  "Deshacer",
  "-",
  "Cortar",
  "Copiar",
  "Pegar (color)",
  "Pegar (no hay color)",
  "-",
  "Seleccionar todo",
  "-",
  "Cambia visualización",
  "-",
  "Optimizar",

  "Ayuda", // Help
};
//************************************************************************
const char* REPLACEDLGPOPUPMENU[] =
{
  "Claro",
  "Deshacer",
  "-",
  "Cortar",
  "Copiar",
  "Pegar (color)",
  "Pegar (no hay color)",
  "-",
  "Seleccionar todo",
  "-",
  "Cambia visualización",
  "-",
  "Optimizar",
};
//************************************************************************
const char* REPLACEMSG[] =
{
"Buscar/Reemplazar (s�lo texto seleccionado)", // de la ventana T�tulos 0 
"Encontrar (s�lo texto seleccionado)", 
"Buscar/Reemplazar (todo el documento)", 
"Encontrar (todo el documento)", 
"", 
"Wrap Around", // Check Boxes 5 
"Case Sensitive", 
"Palabra completa", 
"", 
"&Up", // Botones 9 
"&Down", 
"Remplazar",
"RempTodos", 
"&Cancelar", 
"", 
"Encontrar", // Labels 15 
"Reemplazar", 
"Pulse F3/F4 buscar hacia abajo/arriba", 
"", 
"Texto no encontrado!", // Encontrar estado de retorno 19 
"Fin de la b�squeda", 
"Error en la b�squeda", 
"",
"Sustitución de texto ...", // Varios 23
"Terminó de búsqueda de texto.\n",
" Reemplazos hechos."
"Reemplazar cadena tiene códigos de formato sólo!", // 26
"", // 27
"Haga clic en el descubrimiento o la caja de reemplazar\n"
"a editarlo...", // 28
//------------------------
// Help text (29)
"Prensa Encuentre abajo para buscar hacia adelante para el texto en el cuadro Buscar.\n"
"Prensa Encuentre arriba para buscar hacia atrás para el texto en el cuadro Buscar.\n"
"Presione Reemplazar para reemplazar el texto que se encontró con el texto"
"en el \"Reemplazar con\" caja.\n"
"Pulse \"Reemplazar todo\" para reemplazar todas las ocurrencias.\n\n"
"Para encontrar/reemplazar a lo largo de un área en particular de un documento, arrastre el "
"ratón sobre él para resaltarlo (debe ser uno o más completa "
"líneas de texto!). La Barra de título ahora decir \"(texto seleccionado "
"solamente)\"\n\n"
"1) Utilice el menú Insertar para agregar colores y el texto-formato. (Primera "
"haga clic en el cuadro que desea insertar en para seleccionarlo !) \n"
"2) Haga clic en el menú emergente para copiar/pegar texto, etc\n"
"3) Se puede utilizar (Shift+Ins)/(Shift+Supr) para insertar/borrar texto.\n"
"4) Haga clic izquierdo , arrastre el ratón para seleccionar las zonas de texto (o mantenga "
"el cambio de clave y pulse las teclas de flecha ).\n\n"
"Ejemplo 1: Para reemplazar todas las apariciones de un color en particular:\n"
"a. En el principal programa del tecleo \"Ver\" y selecciona \"Códigos de IRC\".\n"
"b. En el programa principal, arrastre el ratón sobre el color que desee "
"para cambiar (\"C#FF00FF\", por ejemplo), haga clic en Copiar ella"
"y luego haga clic derecho y \"Pegar (Color)\" en el cuadro Buscar.\n"
"c. Ahora copiar/pegar un nuevo color en el \"Reemplazar con\" caja o "
"utilizar el menú Insertar para agregar un código de color.\n"
"d Edite el reemplazar el código de color(s) a su gusto, (Pista: tipo A "
"El personaje ficticio después del código de color(s) y haga clic en Ver->Color "
"para una vista previa de su apariencia, entonces tienes que ir de nuevo a"
"Ver->Códigos para eliminar el carácter ficticio.)\n"
"e. Presione \"Reemplazar todo\", y todos los colores C#FF00FF RGB serán "
"sustituido por el nuevo color.\n"
"f. En el principal programa del tecleo \"Show\" para ver los nuevos colores.\n\n"
"Ejemplo 2: Para buscar / reemplazar texto de múltiples líneas:\n"
"a. Seleccionar, dice un párrafo de texto en el documento principal y "
"haga clic en Copiar en el portapapeles.\n"
"b. No seleccionar el texto haciendo clic en cualquier parte del documento, de modo que "
"no va a ser confundido como una búsqueda de la zona.\n"
"c. Haga clic en Editar -> Buscar para abrir este diálogo y haga clic en "
"\"Pegar normal\" para añadir el texto del párrafo.\n"
"d. Ahora usted puede hacer clic en \"Encuentra Up\" o \"Encuentra Abajo\" para ver si el "
"párrafo aparece más de una vez.\n\n"
"NOTA: Cuando el modo de vista principal es \"Procesado\", el texto Find es "
"Siempre despojado de cualquier formato-códigos para realizar la búsqueda, pero "
"Se permite que el texto Reemplazar tener formato códigos . Cuando el principal "
"modo de vista es \"Códigos de IRC\" o \"Original\", tanto el encontrar y "
"Sustituir los cuadros de texto pueden tener códigos de texto con formato en bruto.", // 29
//----------------------------
// Hints
"Visi�n", // 30 
"Cambiar la vista", // 31
};
//************************************************************************
const char* SPELLINGMSG[] =
{
"Corrector ortogr�fico", // T�tulo de la ventana 0
"Mi diccionario", // DlgShowDict.cpp
"Elija Diccionario", // DlgChooseDict.cpp
"",
"",
"",
"Idioma", // Botones 6
"Reemplazar",
"Reemplazar todo",
"Ayuda",
"No haga caso",
"Ignorar todo",
"Cerrar",
"Agregar palabra",
"Del Palabra (s)",
"",
"Mi diccionario", // (diccionario personalizado) t�tulo Sub-16 de di�logo
"Idioma", // (elija diccionario) Sub-subt�tulo de di�logo 17
"Eliminar Seleccionados", // Sub-18 de di�logo
"Ayuda",
"Cerrar",
"Okay",
"",
"",
"",
"Entradas de diccionario personalizado Max es:", // Cuerdas 25
"No hay faltas de ortografía encontrado, editar diccionario personalizado?", // 26
"No se puede comprobar la ortografía en este sistema ...", // 27

"No se puede encontrar el diccionario. Haga una búsqueda en Internet para \"OpenOffice Diccionarios\"\n"
"y descomprima el archivo. aff y. archivos nórdicos para el diccionario de descargar en nuestro\n"
"carpeta de datos de aplicación, por lo general \"C:\\Program Files (x86)\\\n"
"Discrete-Time Systems\\YahCoLoRiZe\\Dict\"", // 28

"", // 29

"No corrector ortogr�fico: No se puede localizar hunspell.dll\n"
"Prueba a desinstalar y luego reinstalar YahCoLoRiZe ...", // 30

"Agregar la palabra actual a Mi diccionario ...", // 31
"Eliminar la palabra a partir de mi diccionario ...", // 32
"Elegir un (Open Office) diccionario Hunspell ...", // 33
"",
"Hunspell.dll", // hunspell corrector ortogr�fico 35
"",
"",
"",
"",
"Mantenga presionada la tecla Ctrl y haga clic en los elementos que desea eliminar ...", // Sugerencias 40
"",
"",
"",
"",
"",
// --------- Texto de Ayuda para DlgShowDict.cpp
"Seleccione la palabra (s) que desea eliminar manteniendo pulsada la tecla Ctrl\n"
"y hacer clic en ellos (o mantenga la tecla Mayús y haga clic para seleccionar un rango\n"
"de las palabras). Presione la tecla Supr o haga clic en \"Eliminar los elementos seleccionados\"\n"
"para quitar las palabras de la lista ... Click \"Cerca\".", // 46

// --------- Texto de ayuda
"Una palabra mal escrita aparece en la edición-top box con sugerencias\n"
"aparece en el cuadro de lista de la izquierda. Haga clic en una de las sugerencias\n"
"o escribir una nueva palabra.\n\n"
"Haga clic en \"Reemplazar\" para reemplazar una palabra o \"Reemplazar todo\" para sustituir toda\n"
"de las mismas faltas de ortografía de la palabra durante todo el\n"
"documento. Del mismo modo, puede hacer clic en \"No haga caso de\" para continuar con el hechizo\n"
"comprobar sin necesidad de sustituir la palabra o \"Ignore All\" si la palabra es\n"
"bien como está.\n\n"
"Haga clic en \"Idioma\" para abrir una lista de los idiomas disponibles.\n"
"Diccionarios se componen cada uno de los dos archivos, es_ES.aff y es_ES.dic\n"
"para el diccionario de Inglés, por ejemplo. Usted puede colocar más\n"
"diccionarios en el siguiente directorio:\n\n"
"    \\Program Files\\Discrete-Time Systems\\YahCoLoRiZe\\Dict\n\n"
"Asegúrese de copiar los dos archivos (.aff/.dic). Zip archivos disponibles\n"
"diccionarios: http://archive.services.openoffice.org/pub/\n"
"mirror/OpenOffice.org/contrib/dictionaries/\n\n"
"Haga clic en \"Añadir Word\" para agregar una palabra a su propio custom \"Mi diccionario\".\n"
"Al hacer clic en \"Del Word\" Se abrirá un cuadro de lista que le permite\n"
"seleccionar palabras para eliminarlas de su \"Mi diccionario\". Mantenga pulsado el\n"
"Tecla Ctrl y haga clic en varias palabras a continuación, pulse la tecla Supr para eliminar\n"
"ellos.\n\n"
"Créditos: Esta revisión ortográfica se hace posible gracias a los creadores de Hunspell\n"
"así como de los diccionarios de Open Office. El DLL es compilados por Chris de\n"
"www.progui.co.uk. Los diccionarios son de openoffice.org. Hunspell es avalible en:\n"
"hunspell.sourceforge.net.", // 47
};
//************************************************************************
const char * PLAYMSG[] =
{
  // UseDLL->Hint
  "Compruebe este para mIRC/IceChat/Vortec para permitir el uso de burst-\n"
  "interval sin quitar espacios suplementarios (como en Arte de ASCII) .\n"
  "Tambi�n repetici�n de Pausa/Curriculum vitae de permisos en mIRC/Vortec.", // 0

  // StripFont->Hint
  "Compruebe este para quitar etiquetas de fuente para Yahoo. Le deja send\n"
  "una l�nea de texto m�s larga, pero usted tiene que depender del default\n"
  "fuente", // 1

  // UseFile->Hint (for YahELite)
  "Compruebe este para enviar el texto v�a la orden de/textfile de YahELite.", // 2

  // UseFile->Hint (for mIRC/Vortec)
  " UseFile  UseDLL                  Problem                         \n"
  "------------------------------------------------------------------\n"
  "   NO       NO    mIRC strips spaces, Don't use for ASCII Art     \n"
  "   NO      YES    GOOD. ALLOWS ASCII-ART, PAUSE/RESUME/BURST      \n"
  "  YES       NO    Good for ASCII-art but can't pause-play in mIRC \n"
  "  YES      YES    Problem with this, you can't use burst-play...  ", // 3

  // SendUtf8CheckBox->Hint
  "Marque esta para causar todo el texto enviado a su cliente\n"
  "de chat para convertir de ANSI a UTF-8", // 4
  
  // ChanEditKeyDown() - add
  // Spares
  "", // 5
  "", // 6
  "", // 7

  "Juego de canal de forma remota se cambi� a ", // 8
  "el establecimiento de nuevo a ", // 9

  // AddButton->Hint
  "A�adir una nueva sala de uso de texto en el\n"
  "cuadro de edici�n...\n\n"
  "Para introducir un car�cter Unicode, d�gitos\n"
  "hex tipo ictos y pulse Alt+X.", // 10

  "Todas las habitaciones borrado... Pulse Cancelar para deshacer!", // 11

  "Agregado ", // 12
  " a la cuarto-lista!", // 13

  // NoSpaces->Hint
  "En juego, substituya los espacios por _\n"
  "y h�galos invisibles.", // 14

  // NSEdit->Hint
  // This character will be used to form an "invisible space"."
  "Este car�cter ser� usado para\n"
  "formar \"un espacio invisible\".", // 15

  // Rooms->Hint
  "Escriba el nombre de la sala y pulse Intro para agregarlo a\n"
  "la lista. Haga clic en la flecha hacia abajo para ver la lista.", // 16

  "Eliminar una habitaci�n. May�s-clic\n"
  "para borrar todas las habitaciones...", // 17

  "Eliminado ", // 18
  " De sala-list", // 19

  "No se puede eliminar \"estado\"!", // 20

  // Form's captions and lables...

  // Caption
  "Las Opciones de Texto-Repetici�n de T�tulo", //21

  //Label1 
  "Tiempo entre forra-chorros (en Sra) =>", //22

  //Label11 
  "<= Chorro-Intervalo (en Sra) :", //23

  //Label2 
  "Sala de charla (Ejemplo \" #myroom\")"
  "(para la mayor�a de los clientes de usar \"estado\" para poner a prueba)", //24
  
  // SendUtf8
  "Enviar como UTF-8", // 25

  //Label5 
  "el archivo de Temporero para escribir a para la repetici�n:", //26

  //Label6 
  "los byte M�x para enviar", //27

  //StripFont 
  "Pela el Tipo de letra Etiquetas", //28

  //UseDLL 
  "Utiliza DLL", //29

  //UseFile 
  "el Uso Archiva", //30

  //LineBurst 
  "el L�nea-Chorro Calibra", //31

  //NoSpaces 
  "no Espacios", //32

  // ClearRoomsButton
  "Borrar", // 33

  // ResetPathButton
  "Reajustar", // 34

  // Cancel Button
  "Cancelar", // 35

  // PaddingLabel
  "car�cter fil", // 36

  // AddButton
  "A�adir", // 37
  
  // Spares
  "", // 38
  "", // 39

  // SPECIAL!!!!!!!! DO NOT TRANSLATE!!!!!!!!!!!!!!!
  "status", // 40

  // Spares
  "", // 41
  "", // 42
  "", // 43
};
//************************************************************************
const char* FAVCOLORSMAINMENU[] =
{
  "Archivo",

  "Importaci�n",
  "Exportaci�n",
};
//************************************************************************
const char* FAVCOLORSDLG[] =
{
"Colores Favoritos", // Window Title
"Seleccione Color y pulse OK", // Label
"Ejemplo", // List-box text
"A�adir Actual",
"Agregar Nuevo",
"Borrar",
"Guardar",
"Cancelar",
};
//************************************************************************
const char * STRIPDLG[] =
{
"Pele", // Window Title
"Retire C�digos:", // Radiogroup caption
"", // Spares
"",
"Todos c�digos", // MUST REMAIN AT INDEX 4!!!!
"Todos c�digos exteriores Push/Pop",
"c�digos negrita",
"subrayar C�digos",
"Cursiva (o v�deo inverso)",
"Colores del FG",
"Colores del FG",
"Todos colores",
"Todos c�digos de fuente",
"Todos c�digos Push/Pop",
"Ctrl-O",
"Tabulaci�n",
"P�gina",
};
//************************************************************************
const char * MAINPOPUPMENU[] =
// Main popup menu
{
// Men� pop-up
"Claro",
"original",
"proceso",
"comience", // StartPlay1 "comienzan a jugar el texto a un cliente de la charla"
"-",
"Estado del texto en Caret",
"Procese el T�tulo de la Canci�n de SwiftMiX",
"-",
"corte",
"copy",
"goma (Color)", // Paste (Color)
"goma",
"Delete",
"-",
"Seleccione Todos",
};
//************************************************************************
const char * COLORCOPYPASTEMENU[] =
// Color paste menu
{
"Mostrar colores",
"-",
"Copia de color",
"Pegar Color",
"Pega Color de fondo",
};
//************************************************************************
// Main menus, pop-up menu is at the top...
const char * MAINMENU[] =
{
"Archivo", // FileMenu
"Nuevo...", // FileNewItem            "Clear the edit control"
"Abrir Archivo (UTF-8)", // FileOpenItem "abre un archivo existente"
"Abrir Archivo (ANSI)", // FileOpenItem "abre un archivo existente"
"Guardar...", // (Save) FileSaveAsItem
"Guardar Como", // (Save As) FileSaveAsItem
"-", // N1
"Colores De la Mezcla De la Importaci�n", // ImportBlendColors1
"Colores De la Mezcla De la Exportaci�n", // ExportBlendColors1
"-", // N14
"Exportaci�n Como Web-page", // ExportAsWebPage1
"-", // N9
"Configurar P�gina", // FilePageSetup
"Vista Previa Imprima", // FilePreviewItem
"Imprima", // FilePrintItem
"-", // N10
"Salga", // FileExitItem "salida este uso"

"Filetea", // ToolsMenu
"Emoticonos",
"Editar Wings",
"-",
"Establecer Color de primer plano",
"Color del fondo",
"Definir color Wings",
"Definir color Ventana",
"Cambiar la paleta de colores",
"Colores Favoritos", // MenuFavoriteColors
"-",
"Fuente",
"Mapa de caracteres",
"Mostrar Hex",
"Reseed Random Num Gen",
"-",
"Eliminar caracteres de formato",
"Quitar los espacios iniciales/trailing",
"Ajustar Espacios Finales", // Adjust Trailing Spaces
"Unir l�neas en los p�rrafos",
"Optimizar",

"Corrija", // EditMenu
"Claro", // EditClearItem "Clear the Text without disturbing the clipboard"
"Deshaga", // Undo1
"-",
"Corte", // Art�culo seleccionado "Delete selected item"
"Copia", // EditCopyItem "Copy selected item to clipboard"
"Goma (Color)", // EditPasteColor   "Paste contents of clipboard with codes"
"Goma", // EditPasteItem "Paste contents of clipboard"
"Seleccione Todos", // SelectAll1 "Highlight all Text"
"-",
"Hallazgo", // FindText1
"Reemplazar", // ReplaceText1
"-",
"Ortograf�a",

"Ver", // ViewMenu
"original", // Original1
"procesado", // RTF1
"IRC", // IRC1
"HTML", // HTML1
"Fuente del Rtf", // RTFSource1
"-",
"Ver en el explorador", // View In Browser
"-",
"Ajuste l�nea", // WordWrap

"Juego", // PlayMenu
"comience", // StartPlay1 "comienzan a jugar el texto a un cliente de la charla"
"pare", // StopPlay1 "parada que juega el texto a un cliente de la charla"
"pausa", // PausePlay1
"curriculum vitae", // Resume1
"-", // N4
"opciones", // SetPlay1 "fij� el nombre del canal y la velocidad del juego"

"Efect�a", // EffectsMenu

// Format Codes
"El Formato Cifra",
"En negrilla(B)",
"Subrayar(U)",
"It�lica(I)",
"Protegida(P)",
"Final Protegida(p)",
"Texto Llano(O)",
"Color(C)",
"Tipo fuente(F)",
"Tama�o fuente(S)",
"Salto p�gina(N)",

// Font
"Tipo",
"Tipo fuente",
"Tama�o fuente",
"Monta�a",
"Valle",
"Inmersi�n",
"Subida",
"Monta�a Doble",
"Monta�a Enorme",
"Al azar",

"Establecer nuevos colores", // Set New Colors
"Reemplazar color", // Replace Color
"Morph Colorea", // MorphColors1
"Alterno Colorea", // Alternate Colors
"Caracteres Alternos", // AlternateUnderlineBold1
"Increment Colorea", // Increment Colors
"Al azar Colorea", // Random Colors
"Mezcla de FG", // FgBlend
"Mezcla de BG", // BgBlend
"-",
"Genere Color Fractal", // GenerateColorFractal1

// To add a new client, add it to the enumerated types,
// tCli and tCliID, add it here (another entry below)
// and in Main.cpp add it to GetColorizeNetClient()
// and GetInternalClient()
"&Client",
CLIENTS[0],
CLIENTS[1],
CLIENTS[2],
CLIENTS[3],
CLIENTS[4],
CLIENTS[5],
CLIENTS[6],
CLIENTS[7],
CLIENTS[8],

"ayuda", // HelpMenu
"ayuda", // Help1
"Web-Site", // wwwYahCoLoRiZecom1
"-",
"Demo: Arte del ASCII", // ASCIIArtDemo
"Demo: Texto", // TextDemo
"Demo: Texto (Volando)", // TextDemoWings
"Documento T�cnico", // TechDemo
"-",
"Ajustes Del Restore", // RestoreFactorySettings1
"-",
"Informaci�n...", // HelpAboutItem
};
//************************************************************************
// Spanish
const char * KEYSTRINGS[TOTAL_KEY_STRINGS] =
{
"License Days: ", //0
"(Invalid License)", //1

"su ensayo-peri'odo tiene begun!\n"
"para incorporar una llave comprada de la licencia, ayuda del click\n\n"
"instala alrededor Key nuevo\n\n"
"le agradece por intentar mi software!", //2

"había un problema que validaba la llave de la licencia!", //3
"visita", //4
"para comprar este producto!", //5

"su necesidad de obtener una llave y un enter de la licencia\n"
"él para validar este producto", //6

"indirecta: La primera vez que usted funciona este programa,\n"
"usted debe tener derechas de acceso del administrador!", //7

"fije por favor su calendario a la fecha apropiada!", //8
"su activación tiene visita de expired.\n", //9
" a renovar!", //10

"usted debe incorporar el address\n del E-mail"
"que usted utilizó al solicitar su llave de la licencia!", //11

"la dirección del E-mail que usted incorporó no es the\n"
"iguales que eso usado para solicitar su llave de la licencia!", //12

"su nombre de computadora pudo haber cambiado el since\n"
"la vez última que usted utilizó YahCoLoRiZe. ¡Usted necesitará el to\n"
"reinstala la llave de la licencia! Para la información visit:\n\n", //13

"Discrete-Time Systems no serán liable\n llevado a cabo"
"para ninguna daños cualesquiera incluyendo damages\n"
"directo, consecuente, fortuito, especial indirecto, del \n"
"o la pérdida de beneficios de negocio, incluso si Discrete-Time Systems\n"
"(Mister Swift) se ha informado del possibility\n"
"de damages.\n\n"
"si usted CONVIENE, prensa sí, si no, la prensa No.", //14

"Nueva Llave De la Licencia Incorporada Con éxito!", //15

"YahCoLoRiZe se ha activado con éxito!", //16

"el inválido de la llave de la licencia...\n"
"que funciona en el modo restricto, algo ofrece inasequible...", //17

"Key you entered was not valid!", //18

"(Unlimited License)", //19
};
//************************************************************************
// Status messages displayed while busy processing
const char* STATUS[] =
{
  "La fusi�n de tampones...", // 0 Merging buffers
  "Carga de la memoria de la corriente...",  // 1 Loading memory-stream
  "Procesar a formato RTF...", // 2 Processing to RTF format
  "Procesar a formato IRC...", // 3 Processing to IRC format
  "Adici�n de efectos de texto...", // 4 Adding text effect
  "Iniciando el texto de efecto...", // 5 Initializing text-effect
  "Formato viejo pelado...", // 6 Stripping old formatting
  "Optimizaci�n de texto...", // 7 Optimizing text
  "Procesar a formato Yahoo...", // 8 Processing to Yahoo format
  "Procesamiento de texto resaltado caracteres...", // 9 Processing text-highlight chars
  "Procesar a formato HTML...", // 10 Processing to HTML format
  "Nueva Pegar texto...", // 11 Pasting new text
  "Crear font-lista...", // 12 Creating font-list
  "La conversi�n de HTML a IRC...", // 13 Converting from HTML to IRC
};
//************************************************************************
// Color blender tab
const char* BLENDSCOPEITEMS[] =
{
// BlendScopeRadioButtons
"Palabra", // 0
"Line", // 1
"Oraci�n", // 2
"P�rrafo", // 3
"Selecci�n completa", // 4
};
//************************************************************************
const char* BLENDDIRECTIONITEMS[] =
{
// BlendDirectionRadioButtons
"====>>>>", // 0
"==>><<==", // 1
"<<====>>", // 2
"<<<<====", // 3
};
//************************************************************************
const char* TABITEMS[] =
{
// Tab-control
// If you change order, also change:
// TAB_PROCESS   0
// TAB_WIDTH     1
// TAB_MARGINS   2
// TAB_FORMAT    3
// TAB_BLENDER   4
// TAB_OPTIONS   5
// in Main.h and change the TTabSheet PageIndex
"Proceso",
"Anchura",
"Margen",
"Formato",
"Mezclador",
"Opciones",
"Tabs",
};
//************************************************************************
const char* FN[] =
{
"WM_YahELiteExt", // 0
"&Process", // 1
"YahELite:class", // 2
"Colorize.chm", // 3
"Discrete-Time Systems", // 4
"TDTSColor", // 5
"colorize.tmp", // 6
"Colorize.dll", // 7
"xircon", // 8
"command", // 9
"/play -eps", // 10
"/play -p", // 11
"/play stop", // 12
"BlendColors1.bin", // 13
"TDTSTrinity", // 14
"Colorize.ini", // 15
"smileys.txt", // 16
"Smileys\\", // 17
"Dict\\", // 18
"manual.txt", // 19
"asciiart.txt", // 20
"tech.txt", // 21
"Colorize.ico", // 22
"YahCoLoRiZe", // 23 OUR_NAME
"YahCoLoRiZe", // 24 OUR_TITLE
"colorize.htm", // 25
"BlendColors1.txt", // 26
"FavColors.txt", // 27
};
//************************************************************************
const char* DS[TOTALSTRINGS] =
{
"",
"RegisterWindowMessage(WM_ClientExt) fallado.",

// ImportAsciiButton->Hint = XX->Strings[2];
"Izquierdo-tecleo PARA IMPORTAR plain-text\n"
"Derecho-tecleo PARA EXPORTAR plain-text\n\n"
"formato: hasta 10 colores en de la tuerca hexagonal:\n"
"rrggbb etc del rrggbb del rrggbb...",

// XX->Strings[3];
"",

// CheckBox2->Hint = XX->Strings[4];
"Uncheck esto para procesar con del texto efectos\n"
"entonces vu�lvala a inspeccionar, cambie la visi�n a IRC y a ahora\n"
"trate de nuevo el texto para agregar las fronterasalas.",

// PackLines->Hint = XX->Strings[5];
"compruebe para forzar la separaci�n del p�rrafo a 1 l�nea.",

// CheckBox1->Hint = XX->Strings[6];
"Uncheck esto para guardar la original li'nea-rompe.\n"
"compruebe esto para exprimir el texto junto.",

// LeftJustify->Hint = XX->Strings[7];
"compruebe para alinear el izquierdo-margen del texto.",

// ExtendPalette->Hint = XX->Strings[8];
"Active esta opci�n para ampliar el n�mero de colores por defecto m�s\n"
"all� del 16 de las redes y los clientes de IRC futuras. Puede editar\n"
"los colores extendidos en el archivo Colorize.ini.",

// Proceso->Hint = XX->Strings[9];
"Tecleo-Derecho en web-site\n"
"para fijar los colores que usted ve en la tapa.",

// BlendScopeRadioButtons->Hint = XX->Strings[10];
"seleccione el alcance de la mezcla dentro de un bloque del texto seleccionado.",

// BlendDirectionRadioButtons->Hint = XX->Strings[11];
"seleccione la direcci�n de mezclar.",

// RGBThresholdEdit->Hint = XX->Strings[12];
"fije m�s arriba para evitar de enviar demasiados color-datos.",

// XX->Strings[13];
"Elimine todos los archivos instalados?",

// ResolveToPaletteCheckBox->Hint = XX->Strings[14];
"compruebe esto para mantener la opini�n del WYSIWYG exacta.",

// ColorBlenderPresetPanel->Hint = XX->Strings[15];
"Izquierdo-Tecleo a la carga\n"
"el Derecho-Tecleo a ahorrar preestableci�.",

// ImportButton = XX->Strings[16];
"IMPORTAR del Izquierdo-tecleon\n"
"Derecho-tecleo A EXPORTAR.",

// Fronteras = XX->Strings[17];
"tapa de los sistemasfronteras inferiores\n"
"encendido si est� comprobado.",

// Wingdings = XX->Strings[18];
"fija todos los wingdings encendido si est� comprobado.",

// AutoDetectEmotes = XX->Strings[19];
"detecta emocio'n-co'digos si est� comprobado.",

// PlayOnCR->Hint = XX->Strings[20];
"compruebe para causar automo'vil-presionan de\n"
"proceso y automo'vil-juego en un cuarto\n"
"cuando usted golpe� la llave de insertar.",

"Colores RGB no est�n permitidos para IRC de chat-clientes. Intente\n"
"seleccionar Client-> Trinity para que los colores RGB.", // 21

// AddColorCheckBox->Hint = XX->Strings[22];
"compruebe para agregar color al texto en proceso.",

"", // 23

"Alternar Colores", // 24 Alternate Colors
"Aleatorio Colores", // 25 Randomize Colors

"Press to pause text-play.", // 26

// ProcessButton->Hint = XX->Strings[27];
"convierta el texto destacado a a\n"
"formato del color usado en charlar-clientes.",

// PlayButton->Hint = XX->Strings[28];
"presione para jugar el texto en el charlar-cuarto.",

// StopButton->Hint = XX->Strings[29];
"presione para parar el texto-juego.",

// ResumeButton->Hint = XX->Strings[30];
"presione para reasumir el texto-juego.",

// ForegroundColorPanel->Hint = XX->Strings[31];
"Izquierdo-Tecleo para fijar color del primero plano\n"
"Derecho-Tecleo para exhibir color-co'digos del RGB.",

// BackgroundColorPanel->Hint = XX->Strings[32];
"Izquierdo-Tecleo para fijar color del fondo\n"
"Derecho-Tecleo para exhibir color-co'digos del RGB.",

// WingColorPanel->Hint = XX->Strings[33];
"Izquierdo-Tecleo para fijar color del ala\n"
"Derecho-Tecleo para exhibir color-co'digos del RGB.",

// PlayOnCX->Hint = XX->Strings[34];
"Comprobar para recibir y procesar a distancia\n"
"texto (al igual que con la orden de IceChat /CX).",

"Gracias por intentar mi software!", // 35
"Archivo Abierto", // 36
"conversión fallada", // 37
"no puede cargar el archivo...", // 38
"Excepto Archivo", // 39
"ningún nombre de fichero especificó.", // 40
"conversión fallada", // 41
"no puede ahorrar el archivo...", // 42

"selecto: Herramientas->Edit Wingdings, entonces tecleo \"lados\"\n"
"o \"fronteras superiores e inferiores \".", // 43

"selecto: Herramientas->Edit Wingdings, entonces\n"
"chasque los checkboxes wingding que usted prefiere.", // 44

"no hay texto a procesar.", // 45

"Todo Auto-set para Paltalk?\n"
"(Justifica a la izquierda, auto-LINESIZE, no-márgenes,\n"
"Fuente Tahoma, no-fronteras, BG-color es blanco)", // 46

"Pulse para reproducir el texto en el chat-room.\n"
"(mantenga Mayús y hacer clic para enviar mensajes de texto\n"
"para Paltalk sin publicar en la habitación.)", // 47

// Margins On/Off Checkbox Hint
"Marque esta opci�n para convertir texto en todos los m�rgenes.\n"
"Desmarque para convertir todos los m�rgenes de texto OFF.", // 48

"Advertencia: No se puede editar el texto en el modo de ajuste de línea!", // 49

// After Optimizing you may not be able to Undo previous
// changes. Continue?
"Después de Optimización es posible que no pueda Deshacer\n"
"anterior cambios. Continuar?", // 50

"�Pretend�a exportar solo el texto seleccionado como una p�gina web?\n"
"Si no, haga clic en \"no\" y luego haga clic en cualquier parte de su "
"documento para anular la selecci�n del texto...", // 51

"incapaz procesar:", // 52
"", // 53
"proceso de texto abortado por el usuario", // 54
"no podía substituir la Color-tabla del rtf!", // 55
"no podía localizar la Color-tabla del rtf!", // 56
"error del proceso de texto en la conversión del rtf", // 57
"", // 58
"volver-co'digo desconocido del hilo de rosca", // 59
"excepción en SkipSmileys", // 60
"Texto anchura creciente a: ", // 61
"margen cambiante a: ", // 62
"Color Del Primero plano", // 63

"advirtiendo: usted ha fijado color del primero plano\n"
"igual que el color del fondo!", // 64

"Color Del Fondo", // 65

"advirtiendo: usted ha fijado color del fondo\n"
"igual que el color del primero plano!", // 66

"advirtiendo: usted ha fijado color del fondo\n"
"igual que el color del ala!", // 67

"Color Del Ala", // 68

"advirtiendo: usted ha fijado color del ala\n"
"igual que el color del fondo!", // 69

"Presione ESC para salir...", // 70

"advirtiendo: La charla del IRC no puede dirigir el de encargo\n"
"aplicaciones de YahCoLoRiZe de los códigos. Dado vuelta apagado mezcle antes\n"
"el proceso y el mezclador controla...", // 71

"Suplente car�cter", // 72

"Cambio de la fuente es necesario cambiar a la\n"
"Vista de texto original y el reprocesamiento. Cualquier cambio\n"
"usted ha hecho se perderán. ¿Continuar?", // 73

// Replace Color Dialog Help
"Reemplazar color es muy útil si tiene el texto existente con efectos ya\n" 
"agregó, pero sólo tiene que cambiar un color a otro en la selección\n" 
"o en todo el documento. A diferencia Establecer nuevos colores, Reemplazar\n" 
"color deja el todos los demás colores de pre-existentes intacta.\n\n" 
"A la entrada, la inicial De y colores se establecen los mismos que los colores\n"
"en el inicio de la selección. Puede hacer clic en un color para copiar/pegar\n" 
"que de un cuadro a otro. Haga clic izquierdo en un cuadro de color para cambiar\n"
"su color.\n\n"
"*Sugerencia: Antes de seleccionar el texto que desea cambiar el color, puede\n" 
"colores de la copia para usar en cualquier parte del documento seleccionando\n"
"algunos de sus el texto y eligiendo la derecha haga clic en Copiar. Entonces\n"
"usted puede seleccionar la zona para reemplazar colores, elija Efectos->Reemplazar\n"
"color y la derecha, haga clic en Pegar la copia color frontal o de fondo en\n"
"el Para o De color-boxs. :-)", // 74

"Ir a la ficha de Cliente y seleccione Trinidad o\n"
"YahElite para acceder a la mezcla de colores!", // 75

"En la charla de IRC usted sólo puede poner el Valiente, Subrayar, Italics\n"
"atributos de fuente. Ponga el color de fuente haciendo clic el color-panels\n"
"en la etiqueta de Proceso... ¡La cursiva es el VÍDEO INVERSO en IRC!", // 76

"el número más grande de los carbones a seleccionar es 160!", // 77
"usted debe seleccionar el texto para utilizar esta función!", // 78

"Usted está pegando texto que contiene el color de fondo\n"
"en texto sin color de fondo definido.\n\n"
"Quitar los colores de fondo del texto que está pegando?", // 79

"no hay nada imprimir!", // 80

"Impresora No encontrada... Compruebe para ser a segura\n"
"la impresora del defecto se fija para su computadora", // 81

"generador del número al azar re-sembrado!", // 82

"", // 83

"texto demasiado largo. ¿Utilice el sujetapapeles?", // 84

"", // 85

"Sustituido ", // 86
" palabras mal escritas", // 87

"Usted debe ser un administrador para desinstalar YahCoLoRiZe!", // 88

"ajustes de YahCoLoRiZe suprimidos!...Saliendo ", // 89
"Uncheck \"Automo'vil-Mezcle\"\n"
"(lengüeta del formato) permitir", // 90
"ancho", // 91

"Los Ajustes De Defecto Fueron restaurados!", // 92

"fijé esta versión de mi programa para reajustar todos de\n"
"los ajustes de YahCoLoRiZe. Apesadumbrado, pero este vez él\n"
"no podía ser ayudado;) - dxzl ", // 93

"Vieja Versión Detectada! ¿Excepto viejos ajustes?", // 94
"error en: ", // 95
"no podía ahorrar valores del registro", // 96
"conde line", // 97
"Ancho", // 98

"RegOpenKeyEx: Código de seguridad de la lectura de error del registro del!\n"
"usted necesidad de reinstalar YahCoLoRiZe... ;)", // 99

"Haga clic izquierdo para\n"
"la línea de conteo...", // 100

"ADVIRTIENDO!!! Este programa (colorize.el exe) no es la versión\n"
"instaló originalmente.  No puede verificar la autenticidad de.¡Archivo de EXE!", // 101
"incapaz validar, \ del seguridad-co'digon "
"¿usted está utilizando una vieja versión de ventanas?", // 102
"incapaz computar código de seguridad!", // 103
"Código De Seguridad: ", // 104

"(compare este código al código en web-site.\n"
"los códigos deben ser idénticos.  Si no, la versión usted\n"
"tenga puede haber sido alterado, o la versión en el Web site\n"
"fue cambiado por alguien sin autoridad para hacer tan!)", // 105
"incapaz abrirse: ", // 106

"", // 107
"", // 108
"", // 109
"", // 110

"Reinicie el cliente de chat, a continuación, intenta jugar\n"
"otra vez... o tal vez necesidad de comprobar \"PlayOnCX\"\n"
"en la pestaña Opciones ;)", // 111

"usted necesidad de mecanografiar un comando en YahELite de jugar su\n"
"texto en el cuarto.  En el tipo de Client el siguiente\n"
"comando, y entonces el golpe entra en:\n\n"
"/extend TDTSColor YahCoLoRiZe\n\n"
"después de esto, el mensaje \"Extensión Activa\"\n"
"debe demostrar en la charlar-ventana.  Entonces presione el verde\n"
"botón del juego otra vez.", // 112

"advirtiendo: jugar esto en sitio arrogará "
"caracteres de la basura. Usted puede desear\n"
"presionar \"PROCESO \"primero. ¿Cancele el juego?", // 113

"está por encima del límite establecido en Play->Options\n\n"
"chasque... de nuevo tratamiento \ de la Vista->Original y del intenton "
"o sistema \"TextoAnchura Máximo \"a un... más pequeño \ del númeron "
"o AUMENTE el número del umbral del RGB en la lengüeta de la mezcla.", // 114

"Line:", // 115

"no hay nada jugar... ^_^", // 116
"Error al preparar el texto para la reproducción...", // 117

"", // 118

"se cercioran de ambos archivos Colorize.DLL y Xtcl.DLL\n"
"esté en el mismo directorio que YahCoLoRiZe.exe ", // 119

"", // 120
"", // 121
"", // 122
"", // 123
"", // 124

"error que envía comando del juego al mIRC", // 125
"no puede encontrar: ", // 126
"ninguna función de la pausa: ", // 127

"El cambio de vaciar de reguires de cliente todo texto.\n"
"Aprieta OK vaciar.", //128

"ninguna función del curriculum vitae: ", // 129
"la representación de esto al rtf tomará tiempo. Usted puede\n"
"todavía juegue la versión que ahora tenemos... ¿El ir de la subsistencia?", // 130

"no puede cargar: ", // 131
"no puede encontrar ColorStop()", // 132

"", // 133

"Adding an effect is not allowed in this View!", // 134

"Gracias por tratar mi software.\n\n"

"¡Para borrar los iconos de YahCoLoRiZe,\r\n"
"hacer clic con el botón secundariolos y escoger Borra!", // 135

"¿Desinstala YahCoLoRiZe?", // 136
"operación Usuario-cancelada!", // 137
"un error ocurrió en proceso de textos", // 138
"no se seleccionó ningún texto, ¡seleccione alguno!", // 139

"Superposiciones de selección otros efectos...\n"
"Este mensaje ocurre cuando se tiene un\n"
"proteger la zona con unmached PUSH/POP\n"
"códigos incrustados en un texto de selección.", // 140

"de volver-co'digo proceso desconocido", // 141

"Configurar P�gina", // 142 Page Setup
"Imprima", // 143 Print

"", // 144
"", // 145
"", // 146

"los bordes de la frontera no serán uniformes\n"
"después de procesar. ¿Dé vuelta apagado a las fronteras?", // 147

"los bordes de la frontera no serán uniformes"
"después de procesar. ¿Interrupción?", // 148

"el objeto de BlendColors falta...", // 149

"código de error: ", // 150
"archivo de la lectura de error...", // 151

"derecho chasque encendido por lo menos DOS de los mezclar-botones.\n"
"usted debe tener un mínimo de DOS mezclar-colores permitidos!", // 152

"el problema ocurrió en \"CreateBlendEngine\"", // 153

"preestablezca los colores fueron cambiados\n"
"sin el ahorro. ¿Excepto ellos ahora?", // 154

"", // 155

// SaveDialog->Title = XX->Strings[156];
"Colores Del Mezclador De la Exportaci�n", // 156

"", // 157

"no puede ahorrar el archivo...", // 158

// SaveDialog->Title = XX->Strings[159];
"exportaci�n ASCII a la corriente preestablecida", // 159

"el archivo existe, ¿sobreescriba?", // 160
"incapaz abrir el archivo para color-exporte", // 161
"incapaz exportar colores", // 162

// OpenDialog->Title = XX->Strings[163];
"importaci�n ASCII a la corriente preestablecida", // 163

"incapaz abrir el archivo para color-importe", // 164
"incapaz importar colores", // 165

// OpenDialog->Title = XX->Strings[166];
"Colores Del Mezclador De la Importaci�n", // 166

"apesadumbrado, archivo no legible...", // 167

"�Restaurar los valores predeterminados?\n\n"
"Antes de restaurar los valores predeterminados\n"
"es posible que desee exportar sus alas personalizados\n"
"y/o mezclar-colores... ¿Estás seguro de que desea\n"
"restaurar los valores predeterminados?", // 168

"este preestablezca es... vacío\n"
"la derecha del tecleo de ahorrar colores exhibidos.", // 169

"YahCoLoRiZe puede mostrar un archivo .rtf, pero no puede\n"
"convertirlo al formato de c�digo de IRC nativa. YahCoLoRiZe\n"
"funciona con normalidad. No hay convertidor en este momento!", // 170

"ahorrado para preestablecer ", // 171

"advirtiendo: la un-comprobacio'n de esto le dará el RGB puro; sin embargo,\n"
"usted perderá la exactitud del WYSIWYG! ¿Es usted seguro?", // 172
"fijando valores más bajos que", // 173

"pueda \¡nflood el cuarto con color-co'digos!", // 174

// di�logo del Frontera-color
"Color Del Fondo De la Frontera", // 175
"�utilice el espectro completo del RGB?", // 176
"revisi�n: ", // 177
"el color de Forground es ilegal: ", // 178
"el color del fondo es ilegal: ", // 179
"deshacer �ltimo \"proceso\"?", // 180
"", // 181

"Inserte Emoticon acceso directo ...", // 182

"", // 183
"", // 184
"", // 185
"", // 186
"", // 187
"", // 188
"", // 189
"", // 190
"", // 191
"", // 192
"", // 193
"", // 194
"", // 195

// SwiftMixSync Hint
"Marca esta casilla para recibir SwiftMix informaci�n\n"
"de tiempo de reproducci�n.", // 196

// Indirecta "Mezclador->Hint" de la Mezclador-Lengu!eta (usado para los color-botones)
"Izquierdo-Tecleo: Seleccione un color-panel\n"
"Izquierdo-Doble-Tecleo: Elija el color del panel\n"
"Derecho-Tecleo: Accione la palanca del color-panel seleccionado ENCENDIDODE\n"
"Wheel-Up/Abajo: Amortig�e o aclare el color seleccionado\n"
"Rueda-Tecleo: Brillo original del restore", // 197

// Right-click in title-bar to set the colors you see!
"Haga clic derecho en la barra de t�tulo de\n"
"fijar los colores que usted ve!", // 198

// Checkbox-Subti'tulos...
// LeftJustify->Caption
"Ido Justifique", // 199
// PackText->Caption
"Texto Paquete", // 200
// not used
"", // 201
// PackLines->Caption
"Paquete Alinea", // 202
// Fronteras->Caption
"Confina", // 203
// Wingdings->Caption
"Volando", // 204
// AutoDetectEmotes->Caption
"Discierne Emotes", // 205
// PlayOnCR->Caption
"AutoJuego CR", // 206
// SwiftMixSync->Caption
"SwiftMiX Sync", // 207
// ExtendPalette->Caption
"Extend Palette", // 208
// ImportBlenderLabel->Caption
"Importaci�n/Exportaci�n", // 209
// RGBThresholdLabel->Caption
"Umbral del Rgb", // 210

// Right click me!
"Haga-clic aqu�!", // 211

// OK to clear the text and a new client-mode?
"Aceptar para borrar el texto y un nuevo modo de cliente?", // 212

"Seleccione tipo fuente", // 213
"Seleccione tama�o fuente", // 214

"", // 215
"", // 216
"", // 217
"", // 218
"", // 219

// WingColorLabel->Caption
"Volando", // 220

"este preestablezca es vacío...", // 221

"No se puede encontrar...", // 222
"Por favor, vuelva a instalar YahCoLoRiZe...", // 223
"Client: ", //224

// PlayOnCX->Caption
"AutoJuego CX", // 225

"Archivo corrupto...", // 226

"Preparando la desinstalación YahCoLoRiZe, Si un sistema de Windows\n"
"pide permiso para ejecutar el shell de comandos de Microsoft\n"
"haga clic en \"Sí\" y concederle el permiso para funcionar, de lo\n"
"contrario, la desinstalación no se compleated ...", // 227

"El trabajo no guardado, cerca de todos modos?", // 228

"Texto plano transparente no rendirá correctamente a HTML,\n"
"permite de todos modos?", // 229

"", // 230
"", // 231

"Ancho leng�eta", // 232
"Convertir tabulaciones en espacios", // 233

"Comprobaci�n esto insertar� caracteres de"
"tabulaci�n espacios vez de prensa cuando Tab", // 234

"Acoplar aqu� En Proceso", // 235

"Seleccione esta opci�n para sustituir a las pesta�as con\n"
"espacios equivalentes al procesar texto.", // 236

"Gaza aqu� En Proceso", // 237

"Seleccione esta opci�n para sustituir a las pesta�as con un\n"
"solo espacio en el tratamiento de texto.", // 238

"", // 239
"", // 240
"", // 241
"", // 242

// AsIsButton Hint and Label
"Mu�strame", // 243 Button Label

"Representa el texto \"tal cual\" sin fronteras, las alas\n"
"o adicionales de formato de texto de cualquier tipo.\n\n"
"(Push/Pop regiones de texto se muestran en STRIKETHROUGH!)", // 244 Hint

// Auto-linewidth (Width tab)
"Auto", // 245
"Ajuste de la l�nea de longitud a la longitud de la\n"
"l�nea m�s larga del texto", // 246

// Width of text plus wings (Width tab)
"Ancho l�nea", // 247
"Longitud de un texto-line. Esto incluye las alas,\n"
"pero no incluye el margen o secundarios de las fronteras.", // 248

// Left margin (Width tab)
"izquierdo", // 249
"Cantidad de espacio entre el borde izquierdo\n"
"y el texto", // 250

// Indent (Width tab)
"Sangr�a (+/-)", // 251
"P�rrafo gui�n (juego negativo para hacer\n"
"una lista numerada)", // 252

// Right margin (Width tab)
"Derecha", // 253
"Cantidad de espacio entre el borde lateral\n"
"derecho y texto", // 254

// Auto-lineheight (Height tab)
"Auto", // 255
"Altura de las cajas es por los p�rrafos", // 256

// Lines per box (Height Tab)
"altura", // 257
"Las l�neas de texto por caja: 0 = OFF", // 258

// Spacing between boxes (Height Tab)
"espaciamiento", // 259
"Distancia entre cajas: 0 = simple divisi�n", // 260

// # blank lines at top (Height Tab)
"superior", // 261
"N�mero de l�neas en blanco entre el borde\n"
"superior y el texto", // 262

// # blank lines at bottom (Height Tab)
"inferior", // 263

"N�mero de l�neas en blanco entre el borde\n"
"inferior y el texto", // 264

// Margins On/Off Checkbox
"Encienda/Apague", // 265
};
//---------------------------------------------------------------------------
const wchar_t* HTMLCODES[] =
{
  L"&amp;",
  L"&#39;",
  L"&quot;",
  L"&nbsp;",
  L"&gt;",
  L"&lt;",
  L"&cent;",
  L"&curren;",
  L"&divide;",
  L"&copy;",
  L"&micro;",
  L"&pound;",
  L"&euro;",
  L"&yen;",
  L"&trade;",
  L"&sect;",
  L"&reg;",
  L"&para;",
  L"&middot;",
  L"&plusmn;",
  L"&iexcl;",
  L"&sect;",
  L"&brvbar;",
  L"&uml;",
  L"&ordf;",
  L"&laquo;",
  L"&not;",
  L"&macr;",
  L"&deg;",
  L"&sup2;",
  L"&sup3;",
  L"&acute;",
  L"&cedil;",
  L"&sup1;",
  L"&ordm;",
  L"&raquo;",
  L"&frac14;",
  L"&frac12;",
  L"&frac34;",
  L"&iquest;",
  L"&times;",
};
//---------------------------------------------------------------------------
// The index of the char in this string looks up its HTML replacement
// string in the table above.
const wchar_t* HTMLCHARS = L"&\'\",><�����������������������������������";
//---------------------------------------------------------------------------
